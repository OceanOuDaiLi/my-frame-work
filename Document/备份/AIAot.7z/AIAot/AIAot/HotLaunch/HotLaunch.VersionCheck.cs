﻿using System.IO;
using UnityEngine;
using System.Collections;

namespace Zeus.Launch
{
    public partial class HotLaunch
    {
        private bool getResUrl = false;
        private bool getUrlsDown = false;
        private bool totalIntalPkg = false;
        private string mvpText = string.Empty;

        private bool VersionCompare()
        {
            LogProgress("version check pass : " + _localVer + " >= " + _serverVer);
            return float.Parse(_localVer) >= float.Parse(_serverVer);
        }

        private bool GetLocalVersion()
        {
            //1. Get clr version file
            _clrVerFile = IOHelper.LoadINIFile(clrVerFileName);

            if (!_clrVerFile.Exists) { return false; }
            _localVer = System.Text.Encoding.UTF8.GetString(_clrVerFile.Read());

            //2. Get hosts file
            _remoteFile = IOHelper.LoadINIFile(remoteFileName);
            if (!_remoteFile.Exists) { return false; }

            return true;
        }

        private IEnumerator GetTotalPkgInstall()
        {
            if (totalIntalPkg)
            {
                yield break;
            }

            Debug.Log("[HotLaunch:Check] -> 检测是否覆盖安装...");
            string SAVersionPath = Application.platform == RuntimePlatform.IPhonePlayer ? "file://" + Application.streamingAssetsPath + "/Version.txt" : Application.streamingAssetsPath + "/Version.txt";

            using (WWW www = new WWW(GetFileRequestUri(SAVersionPath)))
            {
                yield return www;
                mvpText = www.text;
                Debug.Log("[HotLaunch:Check] -> mvpText： " + mvpText);
            }

            string Persistent_AssetBundlePath = Path.Combine(Application.persistentDataPath, "LocalAssetBundles", "Platform");
            string Persistent_VersionFilePath = Path.Combine(Persistent_AssetBundlePath, "Version.txt");
            bool exit_versionFile = File.Exists(Persistent_VersionFilePath);

            Debug.Log("[HotLaunch:Check] -> exit_ Persistent_VersionFile： " + exit_versionFile);
            if (exit_versionFile)
            {
                string perVersion = File.ReadAllText(Persistent_VersionFilePath);
                totalIntalPkg = mvpText != perVersion;//不一致删除
                Debug.Log("[HotLaunch:Check] -> totalIntalPkg： " + totalIntalPkg);
            }
            else
            {
                totalIntalPkg = false;
            }
        }

        private IEnumerator GetUrls()
        {
            //1. Get cdn url.
            _cdnUrl = System.Text.Encoding.UTF8.GetString(_remoteFile.Read());

            string resHost = string.Format("{0}/{1}/HybridCLR.txt", _cdnUrl, IOHelper.PlatformToName());
            yield return RequestGet(resHost, ResponseGetClrResHost);

            while (!getResUrl)
            {
                yield return null;
            }

            //4. Get urls. 
            string root = string.Format("{0}/{1}/{2}", _cdnUrl, IOHelper.PlatformToName(), _resUrl);
            //-> aotdll url.
            _aotDllsUrl = string.Format("{0}/{1}.bytes", root, aotFileName);
            //-> hotdll url.
            _hotDllsUrl = string.Format("{0}/{1}.bytes", root, hotFileName);
            //-> clr version url.
            _clrVersionUrl = string.Format("{0}/{1}", root, clrVerFileName);
            //-> need update list.txt url.
            _hotlistUrl = string.Format("{0}/{1}", root, hotlistFileName);

            getUrlsDown = true;
            LogProgress("ClrResHost Got... -> _aotDllsUrl - > " + _aotDllsUrl);
        }

        private IEnumerator GetServerVersion()
        {
            if (!string.IsNullOrEmpty(_resUrl))
            {
                yield return RequestGet(_clrVersionUrl, ResponseGetServerVersion);
            }
            else
            {
                //无需热更
                _serverVer = "0";
                _gotServerVersion = true;
            }
        }

    }
}