﻿
namespace Library.Interface.Crypt
{
    /// <summary>
    /// 解析异常
    /// </summary>
    public class DecryptException : RuntimeException
    {
        /// <summary>
        /// 解析异常
        /// </summary>
        /// <param name="message">异常消息</param>
        public DecryptException(string message) : base(message) { }
    }
}