﻿using System.IO;
using Library.IO;
using UnityEngine;
using Library.INI;
using Library.Crypt;
using Library.Interface.IO;

public class IOHelper
{
    private static Crypt _crypt;
    public static Crypt Crypt
    {
        get
        {
            if (_crypt == null)
            {
                _crypt = new Crypt();
                _crypt.SetAdapter(new HMacAes256());
            }
            return _crypt;
        }
    }

    /// <summary>
    /// 初始化IO
    /// </summary>
    private static IO _io;
    public static IO IO
    {
        get
        {
            return _io ?? (_io = new IO());
        }
    }

    //Kings2不对配置文件加密
    private static LocalDisk _assetDisk;
    public static LocalDisk AssetDisk
    {
        get
        {
            return _assetDisk ?? (_assetDisk = new LocalDisk(Application.persistentDataPath));
        }
    }

    private static IniLoader _ini;
    public static IniLoader Ini
    {
        get
        {
            return _ini ?? (_ini = new IniLoader());
        }
    }

    public static IFile LoadINIFile(string fileName)
    {
        IFile file = AssetDisk.File(fileName);
        return file;
    }

    /// <summary>
    /// 将平台转为名字
    /// </summary>
    /// <param name="platform">平台名</param>
    /// <returns>转换后的名字</returns>
    public static string PlatformToName(RuntimePlatform? platform = null)
    {
        if (platform == null)
        {
            platform = Application.platform;
        }
        switch (platform)
        {
            case RuntimePlatform.LinuxPlayer:
                return "Linux";
            case RuntimePlatform.WindowsPlayer:
            case RuntimePlatform.WindowsEditor:
            //return "Win";
            case RuntimePlatform.Android:
                return "Android";
            case RuntimePlatform.IPhonePlayer:
                return "Iphone";
            case RuntimePlatform.OSXEditor:
            case RuntimePlatform.OSXPlayer:
                return "OSX";
            default:
                Debug.LogError("Undefined Platform , [File Helper] = > PlatformToName");
                return "Android";
        }
    }
}
