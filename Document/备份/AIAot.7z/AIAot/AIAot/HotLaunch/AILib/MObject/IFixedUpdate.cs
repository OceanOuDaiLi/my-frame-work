﻿namespace AI
{
    public interface IFixedUpdate
    {
        void DoFixedUpdate(int time);
    }
}
