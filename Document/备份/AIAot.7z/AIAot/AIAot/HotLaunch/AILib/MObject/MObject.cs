﻿using System;
using System.Linq;
using System.Reflection;


namespace AI
{
    public partial class MObject : Container, IMObject
    {
        static protected System.Text.StringBuilder sb = new System.Text.StringBuilder();
        protected const string format = "{0}: state {1} , pos {2}, rot {3}";
        const string c_arg_pix = "__args__";

        private string _str;
        private bool _isInited;
        private int[] _cacheArgs;
        private IFixedUpdate[] _subFixeds;

        public TeamEnum team { get; private set; }
        public PosEnum pos { get; set; }
        public virtual object _match { get; set; }
        public virtual object _rts { get; set; }
        public FSM.IDataSet datas { get; private set; }

        /// <summary>
        /// 表示是否自控，不被外部其他行为控制；
        /// 并不是代表当前是否没事干
        /// </summary>
        public bool isFree { get; set; } = true;

        private int _handDir;
        public int handDir
        {
            get
            {
                return _handDir;
            }
            set
            {
                // UnityEngine.Debug.LogError($"  handDir   {value}  ");
                _handDir = value;
            }

        }
        public int isManToManConfront { get; set; }

        public float[] exts { get; private set; } = new float[8];

        public int flag { get; private set; }

        public virtual IMObject Set(TeamEnum team, PosEnum pos)
        {
            this.team = team;
            this.pos = pos;
            _str = null;
            flag = 0;
            return this;
        }

        public IMObject Set(object sMatch)
        {
            if (sMatch == null)
            {
                return this;
            }

            this._match = sMatch;
            return this;
        }

        public virtual bool IsInited()
        {
            if (_isInited) return true;
            if (isAwake)
            {
                _isInited = true;
                var cs = this.GetChilds();
                if (cs != null && cs.Count > 0)
                {
                    for (int i = 0; i < cs.Count; i++)
                    {
                        if (cs[i] == this) continue;
                        if (cs[i].container == null || (cs[i] is IMObject && !(cs[i] as IMObject).IsInited()))
                        {

                            _isInited = false;
                            break;
                        }
                    }
                }
            }
            if (!_isInited)
                Loger.ELog(this.ToString());
            return _isInited;
        }

        public virtual void DoFixedUpdate(int time)
        {
            if (_subFixeds != null)
            {
                //foreach (var v in _subFixeds) v?.DoFixedUpdate(time);
                //GC优化
                for (int i = 0; i < _subFixeds.Length; i++)
                {
                    if (_subFixeds[i] != null)
                    {
                        _subFixeds[i].DoFixedUpdate(time);
                    }
                }
            }
        }

        public void SetEnable(bool state, bool includeChild = true)
        {
            enable = state;
            if (includeChild)
            {
                var es = GetItems<Entity>();
                if (es != null && es.Count > 0)
                {
                    foreach (var v in es)
                    {
                        if (!v.Equals(this))
                        {
                            if (v is MObject) (v as MObject).SetEnable(state);
                            else v.enable = state;
                        }
                    }
                }
            }
        }
        public Type rtsType = null;
        public Type matchType = null;
        public void SetRelecionType()
        {
            if (Zeus.Launch.HotLaunch.Instance.DEBUG_MODEL)
            {
                Assembly cSharp = AppDomain.CurrentDomain.GetAssemblies().First(assembly => assembly.GetName().Name == "Assembly-CSharp");
                matchType = cSharp.GetType("AI.Match");
                rtsType = cSharp.GetType("AI.RTS");
            }
            else
            {
                matchType = Zeus.Launch.HotLaunch.Instance.GameAsset.GetType("AI.Match");
                if (matchType == null)
                {
                    UnityEngine.Debug.LogError("[MObject::DoAddItems] AI.Match is null");
                }

                rtsType = Zeus.Launch.HotLaunch.Instance.GameAsset.GetType("AI.RTS");
                if (rtsType == null)
                {
                    UnityEngine.Debug.LogError("[MObject::DoAddItems] AI.RTS is null");
                }
            }
        }

        protected sealed override void DoAddItems()
        {
            _isInited = false;

            if (matchType == null || rtsType == null)
            {
                SetRelecionType();
            }

            Type t = container.GetType();
            MethodInfo methodGetItem = t.GetMethod("GetItemReflection").MakeGenericMethod(new Type[] { matchType });
            object match = methodGetItem.Invoke(container, null);
            Set(match ?? match);                               //Set(container.GetItem<Match>() ?? match);
            datas = AddItem<MData>();

            MethodInfo methodSet = t.GetMethod("AddItemReflection").MakeGenericMethod(new Type[] { rtsType });
            _rts = methodSet.Invoke(container, null);            //rts = AddItem<RTS>();

            DoAddComponent();
        }

        protected sealed override void OnPreAddItemsed()
        {
            DoAddComponented();
        }

        protected virtual void DoAddComponent()
        {

        }

        protected virtual void DoAddComponented() { }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            if (_subFixeds != null)
                System.Array.Clear(_subFixeds, 0, _subFixeds.Length);
            _subFixeds = null;

            datas?.Clear();
            _match = null;
            datas = null;
            exts = null;
            _rts = null;
        }

        protected override void OnAddItem(IEntity item)
        {
            base.OnAddItem(item);
            if (item is IFixedUpdate && item != this)
            {
                var idx = _subFixeds == null ? 0 : _subFixeds.Length;
                System.Array.Resize<IFixedUpdate>(ref _subFixeds, idx + 2);
                _subFixeds[idx] = item as IFixedUpdate;
                System.Array.Sort<IFixedUpdate>(_subFixeds, (a, b) =>
                {
                    if (a == null && b == null) return 0;
                    if (a == null) return -1;
                    if (b == null) return 1;
                    return a.ToString().CompareTo(b.ToString());
                });
            }
        }

        protected virtual string Info<E>()
        {
            return null;
        }

        public override string ToString()
        {
            return _str = (_str ?? string.Format("{0}:{1}", team, pos));
        }

        public virtual void VerifyMessages(System.Text.StringBuilder builder)
        {

            if (builder != null)
            {
                builder.AppendLine();
                builder.Append(pos);

                PropertyInfo posInfo = rtsType.GetProperty("pos");
                UnityEngine.Vector3 posValue = (UnityEngine.Vector3)posInfo.GetValue(_rts, null);

                PropertyInfo rotInfo = rtsType.GetProperty("rot");
                UnityEngine.Vector3 rotValue = (UnityEngine.Vector3)rotInfo.GetValue(_rts, null);

                builder.Append(posValue.ToString("f3"));
                builder.Append(rotValue.ToString("f3"));
            }
        }

        public virtual int GetGUID()
        {
            return code;
        }

        public void SetFlag(int flag, bool cancel = false)
        {
            if (flag >= 0)
            {
                if (flag == 0) { this.flag = 0; return; }
                if (cancel)
                    this.flag = this.flag & (~flag);
                else
                    this.flag |= flag;
            }
        }

        public bool CheckFlag(int flag)
        {
            return (this.flag & flag) == flag;
        }

        public IMObject ReadyArgs(int key, bool force = false, int token = 0, int length = 8)
        {
            if (!force && _cacheArgs != null)
            {
                Loger.Warn("当前有正在设置的参数组");
                if (_cacheArgs[0] == token) return this;
            }
            if (key != 0 && datas != null)
            {
                var id = (c_arg_pix + key).ToID();
                _cacheArgs = datas.Get<int[]>(id);
                if (_cacheArgs == null) datas.Set(id, _cacheArgs = new int[length]);
                System.Array.Clear(_cacheArgs, 0, _cacheArgs.Length);
                _cacheArgs[0] = token;
            }
            else _cacheArgs = null;
            return this;
        }


        public T rts<T>()
        {
            return (T)_rts;
        }

        public T match<T>()
        {
            return (T)_match;
        }

        public IMObject SetArgs(int arg, int val, bool end = false)
        {
            if (_cacheArgs != null)
                _cacheArgs[arg] = val;
            if (end) _cacheArgs = null;
            return this;
        }

        public int[] GetArgs(int key, bool endSet = false)
        {
            if (endSet) _cacheArgs = null;
            if (datas != null)
                return datas.Get<int[]>((c_arg_pix + key).ToID());
            return null;
        }
    }

    public class MActor<T> : MObject where T : FSM.FSMState
    {

        public FSM.FSMMachine machine { get; private set; }
        public int currentState
        {
            get
            {
                if (machine != null && machine.curState != null) return machine.curState.key;
                return 0;
            }
        }

        protected override void DoAddComponent()
        {
            machine = AddItem<MFSM>();
            //(machine as MFSM<T>).OnSwitchCall += this.OnFSMStateChange;
            OnFSMAdded();
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            machine = null;
        }

        protected virtual void OnFSMAdded()
        {

        }

        protected virtual void OnFSMStateChange(int state) { }

        protected override string Info<E>()
        {
            sb.Clear();

            if (matchType == null || rtsType == null)
            {
                SetRelecionType();
            }

            PropertyInfo posInfo = rtsType.GetProperty("pos");
            UnityEngine.Vector3 posValue = (UnityEngine.Vector3)posInfo.GetValue(_rts, null);

            PropertyInfo rotInfo = rtsType.GetProperty("rot");
            UnityEngine.Vector3 rotValue = (UnityEngine.Vector3)rotInfo.GetValue(_rts, null);

            sb.AppendFormat(format, this, System.Enum.GetName(typeof(E), machine.curState.key), posValue.ToString("f4"), rotValue.ToString("f4"));
            return sb.ToString();
        }

        public class MFSM : FSM.FSMMachine<T>, IEntity, IFixedUpdate
        {

            private ISystem _container;
            public ISystem container
            {
                get { return _container; }
                set
                {
                    if (_container != value)
                    {
                        _container = value;
                        if (_container != null)
                        {
                            SetDatas(this.container.GetItem<FSM.IDataSet>());
                            Enter(null);
                        }
                    }
                }
            }

            public MFSM() { }

            IFixedUpdate tmpState = null;
            public void DoFixedUpdate(int time)
            {
                tmpState = (curState as IFixedUpdate);
                if (tmpState != null)
                {
                    tmpState.DoFixedUpdate(time);
                }
            }

            public void Release()
            {
                UnInit();
            }

            public override string ToString()
            {
                return container != null ? container.ToString() : base.ToString();
            }

            Type matchType = null;
            public void GetMatchRelecionType()
            {
                if (Zeus.Launch.HotLaunch.Instance.DEBUG_MODEL)
                {
                    Assembly cSharp = AppDomain.CurrentDomain.GetAssemblies().First(assembly => assembly.GetName().Name == "Assembly-CSharp");
                    matchType = cSharp.GetType("AI.Match");
                }
                else
                {
                    matchType = Zeus.Launch.HotLaunch.Instance.GameAsset.GetType("AI.Match");
                    if (matchType == null)
                    {
                        UnityEngine.Debug.LogError("[MObject::DoAddItems] AI.Match is null");
                    }
                }
            }
            protected override void OnStart()
            {
                if (matchType == null)
                {
                    GetMatchRelecionType();
                }

                FSM.IDataSet value = null;
                object matchData = (container as IMObject)._match;
                if (matchData != null)
                {
                    PropertyInfo dataInfo = matchType.GetProperty("datas");
                    value = (FSM.IDataSet)dataInfo.GetValue(matchData, null);
                }


                BindUpValue(true, value);
            }

            protected override void OnSwitch()
            {
                if (curState != null && curState.isEntered)
                {
                    (_container as MActor<T>).OnFSMStateChange(curState.key);
                }
            }

        }

    }

    public class MActor<T, E> : MActor<T> where T : FSM.FSMState where E : struct
    {

        protected sealed override void OnFSMAdded()
        {
            AddItem(new MAutoFSM());
            var ids = MAutoFSM.__IDS__;
            for (int i = 0; i < ids.Count; i++) On(ids[i], OnStateIDEvent, this);
        }

        protected virtual void OnStateIDEvent(object s, object a, IEventArgs e)
        {
            var kid = e.eventID.ToID();
            datas?.Del(kid);
            datas?.Set(kid, e);
            machine?.Switch(e.eventID);
        }

        public class MAutoFSM : FSM.Auto.EnumMachine<E>, IEntity
        {
            private ISystem _container;
            public ISystem container
            {
                get { return _container; }
                set
                {
                    if (_container != value)
                    {
                        _container = value;
                        //FSM.FSMMachine
                        SetMachine(container.GetItem<MFSM>());
                        FSM.FSMMachine tmp = (FSM.FSMMachine)machine;
                        SetAgnet(tmp.datas ?? container.GetItem<FSM.IDataSet>());
                        Init();
                    }
                }
            }

            public MAutoFSM()
            {
            }

            public void Release()
            {
                UnInit();
            }

        }

    }

    public static partial class AotMatchTools
    {
        static public IMObject ReadyArgs<T>(this IMObject entity, T key, bool force = false, int token = 0, int length = 8) where T : struct, System.IConvertible
        {
            return entity?.ReadyArgs(key.ToInt32(null), force, token, length);
        }

        static public IMObject SetArgs<T>(this IMObject entity, T arg, int val, bool end = false) where T : struct, System.IConvertible
        {
            return entity?.SetArgs(arg.ToInt32(null), val, end);
        }

    }

}
