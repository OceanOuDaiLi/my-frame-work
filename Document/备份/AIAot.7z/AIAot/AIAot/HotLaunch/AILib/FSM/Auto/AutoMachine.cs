﻿namespace AI.FSM.Auto
{
    public abstract class AutoMachine : Auto.Processer
    {
        public FSMMachine machine { get; private set; }

        public AutoMachine()
        {
            Singleton<ProcesserSys>.Inst.AddItem(this);
        }

        public override bool Call(IDataSet data)
        {
            //UnityEngine.Debug.unityLogger.logEnabled = true;
            //if (machine != null)
            //{
            //    UnityEngine.Debug.Log("<color=yellow>##########[DaliLi.OU] machine  ##########" + machine.ToString() + " </color>");
            //}
            //UnityEngine.Debug.unityLogger.logEnabled = false;

            if (machine != null && machine.isRuning/*ReflectionGetIsRuning()*/)
            {

                if (/*ReflectionGetCurState()*/machine.curState != null)
                {
                    current = machine.curState.key;/*ReflectionGetCurStateKey();*/

                    base.Call(data ?? machine.datas/*ReflectionGetDatas()*/ ?? agnet);
                }
            }

            return true;
        }

        #region Reflection
        //Type t = null;
        //void GetMachineType()
        //{
        //    if (t != null) { return; }

        //    if (machine == null)
        //    {
        //        UnityEngine.Debug.LogError("[AutoMachine::ReflectionGetMachine] machine is null");
        //        return;
        //    }

        //    t = machine.GetType();
        //    if (t == null)
        //    {
        //        UnityEngine.Debug.LogError("[AutoMachine::ReflectionGetMachine] AI.FSM.FSMMachine is null");
        //        return;
        //    }
        //}


        //bool ReflectionGetIsRuning()
        //{
        //    GetMachineType();

        //    PropertyInfo info = t.GetProperty("isRuning");
        //    bool isRuning = (bool)info.GetValue(machine, null);
        //    return isRuning;
        //}

        //object ReflectionGetCurState()
        //{
        //    GetMachineType();

        //    PropertyInfo info = t.GetProperty("curState");
        //    object curState = info.GetValue(machine, null);
        //    return curState;
        //}

        //int ReflectionGetCurStateKey()
        //{
        //    object curState = ReflectionGetCurState();
        //    Type t = curState.GetType();
        //    if (t == null)
        //    {
        //        UnityEngine.Debug.LogError("[AutoMachine::ReflectionGetMachine] [FSMState] machine.curstate is null");
        //    }
        //    PropertyInfo info = t.GetProperty("key");

        //    int key = (int)info.GetValue(curState, null);

        //    return key;
        //}

        //IDataSet ReflectionGetDatas()
        //{
        //    GetMachineType();

        //    PropertyInfo info = t.GetProperty("datas");
        //    IDataSet _data = (IDataSet)info.GetValue(machine, null);

        //    //UnityEngine.Debug.Log("<color=red>##########ReflectionGetDatas ##########   data == null ? " + (_data == null).ToString() + " </color>");
        //    return _data;
        //}

        //void ReflectionCallSwitch(int idx)
        //{
        //    GetMachineType();

        //    MethodInfo method = t.GetMethod("Switch");
        //    method.Invoke(machine, new object[] { idx });
        //}
        #endregion


        public void SetMachine(object machine)
        {
            if (this.machine != null) this.machine = null;
            this.machine = machine as FSMMachine;

            SetAgnet(this.machine.datas/*ReflectionGetDatas()*/);
        }

        protected override bool Check(Transition child)
        {
            return base.Check(child) || (child.source <= 0 && child.target != current);
        }

        protected override void OnChangeTo(int idx)
        {
            if (machine != null)
            {
                if (select.select.arg != null)
                {
                    var id = idx.ToID();
                    IDataSet _data = machine.datas;//ReflectionGetDatas();

                    if (_data != null)
                    {
                        _data.Del(id);
                        _data.Set(id, select.select.arg.val);
                    }
                }

                machine.Switch(idx);
                //ReflectionCallSwitch(idx);
            }
        }

        public override void Reset()
        {
            machine = null;
            base.Reset();
            Singleton<ProcesserSys>.Inst.DelItem(this);
        }

        static public void AddToLoop(Processer process)
        {
            Singleton<ProcesserSys>.Inst.AddItem(process);
        }

        static public void DelFromLoop(Processer process)
        {
            Singleton<ProcesserSys>.Inst.DelItem(process);
        }
    }

    class ProcesserSys : System<Auto.Processer>
    {

        protected override bool Filter(Processer component)
        {
            return base.Filter(component) && component.enable && component.isInited;
        }

        protected override void Update(float time, Processer component)
        {
            if (component != null) component.Call(null);
        }
    }
}

