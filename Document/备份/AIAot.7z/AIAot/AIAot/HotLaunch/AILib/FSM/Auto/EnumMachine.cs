﻿namespace AI.FSM.Auto
{
    using System;
    using System.Collections.Generic;

    public class EnumMachine<T> : AutoMachine where T : struct
    {
        static public readonly Type __TYPE__;
        static public readonly IReadOnlyList<int> __IDS__;
        static private readonly Dictionary<int[], ConditionAttribute[]> _trans;

        static EnumMachine()
        {
            __TYPE__ = typeof(T);
            if (!__TYPE__.IsEnum) throw new System.Exception("泛型参数的类型必须是枚举类型");
            if (!Attribute.IsDefined(__TYPE__, typeof(FlagsAttribute))) throw new System.Exception("枚举类型必须使用[Flags]标记");
            var vs = Enum.GetValues(__TYPE__);
            var ns = Enum.GetNames(__TYPE__);

            var ks = new List<int>();
            var ts = new List<string>();
            var bls = new Dictionary<string, int[]>();

            var l = ns.Length;
            for (int k = 0; k < l; k++)
            {
                var i = (int)vs.GetValue(k);
                if (Enum.GetName(__TYPE__, i).StartsWith("__") || i == 0) continue;

                var n = ns[k];
                if (i > 0)
                {
                    if (Math.Pow(2, (int)Math.Log(i, 2)) == i)
                    {
                        ks.Add(i);
                        continue;
                    }
                }
                ts.Add(n);

            }
            __IDS__ = ks.ToArray();
            if (ts.Count > 0)
            {
                var f = false;
                for (int i = ts.Count - 1; i >= 0; i--)
                {
                    f = false;
                    T e = default(T);
                    var k = ts[i];
                    var t = 0;

                    if (Enum.TryParse<T>(k, out e))
                    {
                        t = (int)(object)e;

                        if (Math.Abs(t) > 2)
                        {
                            for (int j = 0; j < ks.Count - 1; j++)
                            {
                                var t1 = ks[j];
                                var t2 = Math.Abs(t);
                                t2 = t2 ^ t1;
                                if (ks.Contains(t2))
                                {
                                    f = true;
                                    if (t1 > t2)
                                    {
                                        if (t > 0) bls[k] = new int[] { t2, t1 };
                                        else bls[k] = new int[] { t1, t2 };
                                    }
                                    else
                                    {
                                        if (t > 0) bls[k] = new int[] { t1, t2 };
                                        else bls[k] = new int[] { t2, t1 };
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    if (f) ts.RemoveAt(i);
                }

                if (ts.Count > 0)
                {
                    foreach (var v in ts)
                    {

                        var t = __TYPE__.GetField(v).GetCustomAttributes(typeof(TransitionAttribute), false) as TransitionAttribute[];
                        if (t != null && t.Length > 0)
                        {
                            foreach (var i in t)
                            {
                                if (i.dst != 0)
                                {
                                    bls[v] = new int[] { i.src, i.dst };
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            if (bls.Count > 0 || ks.Count > 0)
            {
                _trans = new Dictionary<int[], ConditionAttribute[]>();
                foreach (var item in bls)
                {
                    var cs = __TYPE__.GetField(item.Key.ToString()).GetCustomAttributes(typeof(ConditionAttribute), false) as ConditionAttribute[];
                    _trans[item.Value] = cs;
                }

                foreach (var e in ks)
                {
                    var cs = __TYPE__.GetField(((T)(object)e).ToString()).GetCustomAttributes(typeof(ConditionAttribute), false) as ConditionAttribute[];
                    if (cs != null && cs.Length > 0) _trans[new int[] { 0, e }] = cs;
                }
            }
        }


        public EnumMachine()
        {
            InitMachineTrans(this);
        }

        protected override void OnChangeTo(int idx)
        {
            if (machine != null)
            {
                agnet?.Set((uint)idx, false);
                agnet?.Set((uint)current, false);
                base.OnChangeTo(idx);
            }
        }

        static public void InitMachineTrans(AutoMachine machine)
        {
            if (machine != null && _trans != null && _trans.Count > 0)
            {
                foreach (var v in _trans)
                {
                    bool s = false;
                    var arg = string.Empty;
                    if (v.Value != null && v.Value.Length > 0)
                    {
                        foreach (var c in v.Value)
                        {
                            if (c.left != null || c.leftID > 0)
                            {
                                s = true;
                                if (c.leftID > 0) machine.While(c.leftID, c.right, c.type, c.isRef, c.compare, c.ext, c.layer, c.otherCompare);
                                else machine.While(c.left, c.right, c.type, c.isRef, c.compare, c.ext, c.layer, c.otherCompare);
                                if (arg == null && c.arg != null) arg = c.arg;
                            }
                        }
                        if (s) machine.Arg(arg).Switch(v.Key[0], v.Key[1]);
                    }
                    else machine.While<bool>((uint)v.Key[0], true, Lib.P.CompareOp.Eq).Switch(v.Key[0], v.Key[1]);
                }
            }
        }
    }

}
