﻿using System.Collections.Generic;

namespace AI.FSM.Auto
{
    public interface ISwitchCall<T>
    {
        int order { get; set; }
        int key { get; set; }
        bool result { get; }
        bool Check(T data);
        bool Call(T data);
        void Reset();
    }


    public abstract class SwitchList<S, P> : List<S>, ISwitchCall<P> where S : ISwitchCall<P>
    {
        private static System.Comparison<S> _compare;
        private bool _hasSelected = false;
        private bool _isFirst = true;

        private bool _isReseted = false;
        public S select { get; private set; }
        public bool result { get; private set; } = true;
        public int order { get; set; }
        public int key { get; set; }
        public bool checkEveryOne { get; set; }
        public bool compareLastResult { get; set; } = true;

        static SwitchList()
        {
            _compare = new System.Comparison<S>(SortCompare);
        }

        public virtual bool Check(P data)
        {
            return true;
        }

        public virtual bool Call(P data)
        {
            if (Count > 0)
            {
                _hasSelected = false;
                select = default(S);
                Sort(_compare);
                var l = Count;
                for (int i = 0; i < l; i++)
                {
                    var s = this[i];
                    if (s != null && Check(s))
                    {
                        var lr = s.result;
                        var ret = s.Check(data) && s.Call(data);
                        if (ret && !_hasSelected) { select = s; _hasSelected = true; }
                        if (_isFirst || !compareLastResult || ret != lr) { OnChecked(s, ret); }
                        if (_hasSelected && !checkEveryOne) break;
                    }
                }
                result = _hasSelected;
                _isFirst = false;
            }
            else result = true;
            return result;
        }

        public virtual void Reset()
        {
            if (Count > 0)
                this.ForEach((c) => { if (c != null) c.Reset(); });
            Clear();
            select = default(S);
        }

        public S Find(int key)
        {
            if (Count > 0)
                return Find(s => s.key == key);
            return default(S);
        }

        public abstract S Add<T>(int key) where T : S;

        public virtual S Get(int key, bool ifMissAdd = true)
        {
            var s = Find(key);
            if (s == null && ifMissAdd)
            {
                s = Add<S>(key);
                if (s != null) { s.key = s.key == 0 ? key : s.key; Add(s); }
            }
            return s;
        }

        public virtual S Del(int key)
        {
            var s = Find(key);
            if (s != null) Remove(s);
            return s;
        }

        protected virtual bool Check(S child)
        {
            return true;
        }

        protected virtual void OnChecked(S child, bool state) { }

        public static int SortCompare(S a, S b)
        {
            return a.order.CompareTo(b.order);
        }
    }
}
