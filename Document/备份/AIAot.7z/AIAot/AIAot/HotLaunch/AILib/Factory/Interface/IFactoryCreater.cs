
public interface IFactoryCreater
{
    object Creater(object type, int uniqid = 0);
}

public interface IFactoryCreater<T> : IFactoryCreater
{
    T Creater(int uniqid = 0);
}