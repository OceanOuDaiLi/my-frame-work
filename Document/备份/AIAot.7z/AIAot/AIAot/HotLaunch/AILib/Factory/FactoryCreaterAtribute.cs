using System;
using System.Collections.Generic;

public class FactoryCreaterAtribute : Attribute
{
    public Type creater { get; set; }

    public FactoryCreaterAtribute(Type creater) { }
}