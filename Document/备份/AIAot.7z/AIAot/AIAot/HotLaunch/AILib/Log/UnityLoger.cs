﻿using System.Diagnostics;

namespace AI
{
    public class UnityLoger : ILog
    {
        const char msg_start = '$';
        const char msg_start_2 = '[';
        const string msg_format = "$[{0}]:{1} => {2}";
        const string time_format = @"hh\:mm\:ss\.fff";

        public override LogType logMask { get; set; } = LogType.Info | LogType.Log | LogType.Warn | LogType.Error | LogType.IO | LogType.Other;

        Stopwatch watch;

        public UnityLoger()
        {
            if (loger == null) loger = this;

            watch = new Stopwatch();
            watch.Restart();
            if (abductNativeLog)
            {
                UnityEngine.Application.logMessageReceived += Application_logMessageReceived;
            }
        }

        private void Application_logMessageReceived(string condition, string stackTrace, UnityEngine.LogType type)
        {
            if (string.IsNullOrEmpty(condition) || (condition[0] == msg_start && condition[1] == msg_start_2)) return;
            Print(U2L(type) | LogType.Other, condition);
        }

        LogType U2L(UnityEngine.LogType logType)
        {
            switch (logType)
            {
                case UnityEngine.LogType.Error: return LogType.Error;
                case UnityEngine.LogType.Log: return LogType.Log;
                case UnityEngine.LogType.Warning: return LogType.Warn;
            }
            return LogType.Log;
        }

        public override void Print(LogType type, string msg)
        {
            if (!forbidLog && (type & logMask) == type)
            {
                var t = logCountCB != null ? logCountCB() : watch.Elapsed.ToString(time_format);
                type = type & (~LogType.Other);
                msg = string.Format(msg_format, t, type, msg);

                if (enableLog)
                {
                    switch (type)
                    {
                        case LogType.Info:
                        case LogType.Log: UnityEngine.Debug.Log(msg); break;
                        case LogType.Warn: UnityEngine.Debug.LogWarning(msg); break;
                        case LogType.Error: UnityEngine.Debug.LogError(msg); break;
                    }
                }

                logCallBack?.Invoke(type, msg);
            }
        }

        public override void Print(LogType type, string msg, params object[] args)
        {
            if (forbidLog) return;
            Print(type, string.Format(msg, args));
        }
    }
}
