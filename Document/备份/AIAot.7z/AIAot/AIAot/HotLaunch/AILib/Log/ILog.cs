
namespace AI
{
    [System.Flags]
    public enum LogType : byte
    {
        Info = 1,
        Log = 2,
        Warn = 4,
        Error = 8,
        IO = 16,
        Other = 32,
        __MAX__ = Info | Log | Warn | Error | IO | Other,
    }

    public class ILog
    {
        public static bool enableLog = true;

        public static bool forbidLog = false;

        public static System.Action<LogType, string> logCallBack;

        public static System.Func<object> logCountCB;

        public bool abductNativeLog = false;

        public virtual LogType logMask { get; set; }

        public static ILog loger { get; protected set; }

        public virtual void Print(LogType type, string msg) { }

        public virtual void Print(LogType type, string msg, params object[] args) { }

    }
}