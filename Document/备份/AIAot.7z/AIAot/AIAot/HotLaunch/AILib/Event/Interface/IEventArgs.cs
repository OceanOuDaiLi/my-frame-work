namespace AI
{
    public interface IEventArgs
    {
        int eventID { get; set; }
        void Reset();
    }
}