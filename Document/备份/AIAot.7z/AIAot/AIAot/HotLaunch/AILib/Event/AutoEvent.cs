﻿using System;
using System.Collections.Generic;
using System.Reflection;

[AttributeUsage(AttributeTargets.Event | AttributeTargets.Method, AllowMultiple = true)]
public class AutoEventAttribute : Attribute
{
    public string eventName { get; set; }

}

public static class AutoEventUtil
{
    static private BindingFlags G_FLAG = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance | BindingFlags.Instance;
    static private Dictionary<Type, Dictionary<string, EventInfo>> _events = new Dictionary<Type, Dictionary<string, EventInfo>>();
    static private Dictionary<Type, Dictionary<string, List<MethodInfo>>> _methods = new Dictionary<Type, Dictionary<string, List<MethodInfo>>>();

    static private Dictionary<string, EventInfo> GetPartialEvents(Type ty)
    {

        var es = ty.GetEvents(G_FLAG);
        if (es != null && es.Length > 0)
        {
            var dic = new Dictionary<string, EventInfo>();
            foreach (EventInfo v in es)
            {
                IEnumerable<AutoEventAttribute> os = v.GetCustomAttributes<AutoEventAttribute>();
                if (os != null)
                {
                    IEnumerator<AutoEventAttribute> e = os.GetEnumerator();
                    while (e.MoveNext())
                    {
                        string n = e.Current.eventName ?? v.Name;
                        if (!dic.ContainsKey(n))
                            dic[n] = v;
                        else
                            throw new Exception(string.Format("类型[{0}]已存在事件名为[{1}]的事件，事件类型对象为[{2}]", ty.FullName, n, v.Name));
                    }
                }
            }
            return dic;
        }
        return new Dictionary<string, EventInfo>();
    }

    static private Dictionary<string, List<MethodInfo>> GetBindMethods(Dictionary<string, EventInfo> dic, Type ty)
    {
        if (ty != null && dic != null && dic.Count > 0)
        {
            MethodInfo[] ms = ty.GetMethods(G_FLAG | BindingFlags.InvokeMethod);
            if (ms != null && ms.Length > 0)
            {
                var fms = new Dictionary<string, List<MethodInfo>>();
                foreach (MethodInfo v in ms)
                {
                    IEnumerable<AutoEventAttribute> os = v.GetCustomAttributes<AutoEventAttribute>();
                    if (os != null)
                    {
                        IEnumerator<AutoEventAttribute> a = os.GetEnumerator();
                        while (a.MoveNext())
                        {
                            AutoEventAttribute it = a.Current;
                            if (!string.IsNullOrEmpty(it.eventName))
                            {
                                if (dic.ContainsKey(it.eventName))
                                {
                                    var ls = fms.ContainsKey(it.eventName) ? fms[it.eventName] : new List<MethodInfo>();
                                    ls.Add(v);
                                    fms[it.eventName] = ls;
                                }
                            }
                        }
                    }
                }
                return fms;
            }
        }
        return null;
    }

    static public void PreExute(object inst)
    {
        if (inst != null)
        {
            Type ty = inst.GetType();
            if (ty.IsClass)
            {
                Dictionary<string, EventInfo> events = null;
                Dictionary<string, List<MethodInfo>> methods = null;
                try
                {
                    if (!_events.TryGetValue(ty, out events))
                    {
                        events = GetPartialEvents(ty);
                        methods = GetBindMethods(events, ty);

                        _events[ty] = events ?? new Dictionary<string, EventInfo>();
                        _methods[ty] = methods;
                    }
                    else
                    {
                        _methods.TryGetValue(ty, out methods);
                    }
                }
                catch (Exception e)
                {
                    UnityEngine.Debug.LogException(e);
                }

                if (events != null && events.Count > 0 && methods != null && methods.Count > 0)
                {
                    foreach (var n in methods)
                    {
                        if (events.ContainsKey(n.Key))
                        {
                            EventInfo e = events[n.Key];
                            foreach (var m in n.Value)
                            {
                                try
                                {
                                    if (m != null)
                                        e.GetAddMethod(true).Invoke(inst, new object[] { m.CreateDelegate(e.EventHandlerType, inst) });
                                }
                                catch (Exception ex)
                                {
                                    UnityEngine.Debug.LogException(ex);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
