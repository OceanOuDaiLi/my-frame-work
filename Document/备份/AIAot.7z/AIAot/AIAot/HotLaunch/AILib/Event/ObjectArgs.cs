using System;

namespace AI
{
    public class ObjectArgs : IEventArgs
    {
        static public readonly ObjectArgs Args = new ObjectArgs();

        public int eventID { get; set; }
        public object[] args { get; set; }

        public object a;
        public object b;
        public object c;

        public void Reset()
        {
            eventID = 0;
            if (args != null) Array.Clear(args, 0, args.Length);
            args = null;
            a = b = c = null;
        }

        public ObjectArgs Set(int id, params object[] args)
        {
            eventID = id;
            this.args = args;
            return this;
        }

        public ObjectArgs SetVal(object a, object b, object c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
            return this;
        }

    }
}
