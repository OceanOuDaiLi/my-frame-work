﻿using System;
using System.Collections.Generic;

namespace AI
{
    #region Interface

    public interface IEntity : IRelease
    {
        ISystem container { get; set; }
    }

    public interface INoLife { }

    public interface IRunable
    {
        void Update(float time);
    }

    public interface ISystem : IRunable, IEmitter
    {
        int version { get; }

        P AddItem<P>(int key) where P : class;

        P AddItem<P>() where P : class;

        P GetItem<P>() where P : class;

        P GetItemReflection<P>() where P : class;

        List<P> GetItems<P>() where P : class;


        P GetItem<P>(Func<P, bool> func) where P : class;

        void AddItem(object item);

        void DelItem(object item);

    }

    #endregion

    #region System

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public class RequireAttribute : Attribute
    {
        public Type type { get; set; }

        public RequireAttribute(Type type)
        {
            this.type = type;
        }
    }

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public class DependAttribute : Attribute
    {
        public Type type { get; set; }

        public DependAttribute(Type type)
        {
            this.type = type;
        }
    }

    public static class NeedPauseCondition
    {
        public static Func<bool> Func;
    }

    public abstract class System<T> : Entity, ISystem where T : class
    {
        public readonly static Type C_COM_TYPE = typeof(T);

        public int version { get; private set; }

        protected Func<T, bool> filter { get; private set; }
        private IList<T> _childs;
        private IList<T> _temps;
        private T _self;

        protected override bool allowUpdate => true;

        protected virtual bool canAddSelf => false;
        protected virtual bool addToLoop => true;
        protected virtual bool noFilter => false;


        public System()
        {
            filter = new Func<T, bool>(Filter);
            enableTrigger = true;

            if (this is Loop || !addToLoop) return;

            Singleton<Loop>.Inst.AddItem(this);
        }

        protected virtual bool onlyManageSelfComs
        {
            get
            {
                return false;
            }
        }

        protected override void Awake()
        {
            PreAddItems();
        }

        protected override void Start()
        {
            OnPreAddItemsed();
        }

        protected override void OnDestroy()
        {
            if (_childs != null)
            {
                var l = _childs.Count;
                for (int i = l - 1; i >= 0; i--)
                    DelItem(_childs[i]);
            }
            if (_temps != null) _temps.Clear();
            _childs = null;
            _temps = null;
            Singleton<Loop>.Inst.DelItem(this);
        }

        protected IList<T> GetComponents()
        {
            return GetSelfItems(ref _temps);
        }

        protected IList<T> GetChilds()
        {
            return _childs;
        }

        protected virtual IList<T> GetSelfItems(ref IList<T> list, Func<T, bool> filter = null, int count = -1)
        {
            if (_childs != null && _childs.Count > 0)
            {
                int num = _childs.Count;
                filter = filter ?? this.filter;
                for (int i = 0; i < num; i++)
                {
                    if (filter(_childs[i]))
                    {
                        list = list ?? new List<T>();
                        list.Add(_childs[i]);
                        if (count > 0 && count <= list.Count) break;
                    }
                }
            }
            return list;
        }

        public new virtual void Update(float time)
        {

            if (Condition())
            {
                var list = noFilter ? _childs : GetComponents();
                if (list != null && list.Count > 0)
                {
                    for (int i = list.Count - 1; i >= 0; i--)
                    {
                        var c = list[i];
                        if (c != null && _self != c)
                        {
                            try
                            {
                                if (CheckItemCanBeRemoved(c)) { DelItem(c); continue; }
                                Update(time, c);
                            }
                            catch (Exception e)
                            {
                                Loger.Exception(e);

                                if (Zeus.Launch.HotLaunch.Instance.DEBUG_MODEL)
                                {
                                    UnityEngine.Debug.LogError($" exception  {e}  ");
                                }

                            }
                        }
                    }
                    if (!noFilter) list.Clear();
                }
                DoUpdate(time);
            }
        }

        protected virtual void DoUpdate(float time)
        {

        }

        protected abstract void Update(float time, T component);

        protected virtual bool Filter(T component)
        {
            return component != null && !component.Equals(this);
        }

        protected virtual bool Condition()
        {
            return InvokeUpdateCondition();
        }

        protected virtual bool InvokeUpdateCondition()
        {
            if (NeedPauseCondition.Func != null)
            {
                try
                {
                    bool c = NeedPauseCondition.Func.Invoke();
                    return c;
                }
                catch
                {
                    return false;
                }
            }
            return false;
        }

        protected virtual bool CheckItemCanBeRemoved(T item)
        {
            return false;
        }

        public T AddItem(int key)
        {
            var t = Creater(key);
            AddItem(t);
            return t;
        }

        public P AddItem<P>() where P : class, T
        {
            var t = (P)Creater<P>();
            AddItem(t);
            return t;
        }

        public P AddItemReflection<P>() where P : class, T
        {
            var t = (P)Creater<P>();
            AddItem(t);
            return t;
        }


        public virtual void AddItem(T item)
        {
            if (item != null && (canAddSelf || !Equals(item)))
            {
                _childs = _childs ?? CreateList();
                if (!_childs.Contains(item))
                {
                    if (_self == null && item == this) _self = item;
                    _childs.Add(item);
                    version++;
                    OnAddItem(item);
                }
            }
        }

        public virtual void DelItem(T item)
        {
            if (item != null && _childs != null && _childs.Contains(item))
            {
                _childs.Remove(item);
                version++;
                OnDelItem(item);
            }
        }


        public virtual List<P> GetItems<P>() where P : class
        {

            //#warning  These are some Codes,Need to opt.
            IList<T> ls = null;
            var rets = new List<P>();
            GetSelfItems(ref ls, (c) =>
            {
                if (c != null && c is P)
                {
                    rets.Add(c as P);
                }
                return false;
            });
            return rets;
        }

        public virtual P GetItemReflection<P>() where P : class
        {
            for (int i = 0; i < _childs.Count; i++)
            {
                var item = _childs[i];
                if (item is P)
                    return item as P;
            }

            return default(P);
        }

        public virtual P GetItem<P>() where P : class
        {
            for (int i = 0; i < _childs.Count; i++)
            {
                var item = _childs[i];
                if (item is P)
                    return item as P;
            }

            return default(P);
        }


        public virtual P GetItem<P>(Func<P, bool> func) where P : class
        {
            if (func != null)
            {
                for (int i = 0; i < _childs.Count; i++)
                {
                    var item = _childs[i];
                    if (item is P && func(item as P))
                    {
                        return item as P;
                    }
                }
            }

            return default(P);
        }

        protected virtual T Creater(int key)
        {
            return Factory<T>.Uniqid(key);
        }

        protected virtual T Creater<P>() where P : class
        {
            try
            {
                return Factory<P>.Create() as T;
            }
            catch (Exception e)
            {
                Loger.Exception(e);
            }
            return default(T);
        }

        protected virtual void OnAddItem(T item) { }

        protected virtual void OnDelItem(T item) { }

        protected virtual List<T> GetInitItem()
        {
            return null;
        }

        protected virtual void DoAddItems()
        {

        }

        protected virtual void OnPreAddItemsed() { }

        protected virtual IList<T> CreateList()
        {
            return new List<T>();
        }

        private void PreAddItems()
        {
            var its = GetInitItem();
            if (its != null && its.Count > 0) foreach (var v in its) AddItem(v);
            DoAddItems();
        }

        P ISystem.AddItem<P>()
        {
            return Creater<P>() as P;
        }

        P ISystem.AddItem<P>(int key)
        {
            return AddItem(key) as P;
        }

        void ISystem.AddItem(object item)
        {
            AddItem((T)item);
        }

        void ISystem.DelItem(object item)
        {
            DelItem((T)item);
        }
    }

    public abstract class ESystem<T> : System<T> where T : Entity
    {
        protected override bool Filter(T component)
        {
            return base.Filter(component) && (component.enable || component.isDestroy);
        }

        protected override IList<T> CreateList()
        {
            return base.CreateList();
        }
    }

    public class Container : System<IEntity>
    {
        protected sealed override bool addToLoop => false;
        protected override bool canAddSelf => true;

        public bool isRuning { get; private set; }

        public Container()
        {
            Singleton<ContainerSys>.Inst.AddItem(this);
        }

        public void Run()
        {
            if (isRuning) return;
            isRuning = true;
        }

        public void Exit()
        {
            if (!isRuning) return;
            isRuning = false;
        }

        protected override bool Filter(IEntity component)
        {
            return component != null && component.container == null;
        }

        protected override void Update(float time, IEntity component)
        {
            component.container = this;
        }

        public override void AddItem(IEntity item)
        {
            base.AddItem(item);
            if (item != null) item.container = null;
        }

        public override void DelItem(IEntity item)
        {
            base.DelItem(item);
            if (item != null) item.Release();
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            Singleton<ContainerSys>.Inst.DelItem(this);
        }

        class ContainerSys : ESystem<Container>
        {
            protected override bool Filter(Container component)
            {
                return base.Filter(component) && component.isRuning && component.isAwake;
            }

            protected override void Update(float time, Container component)
            {
                component.Update(time);
            }

            protected override bool CheckItemCanBeRemoved(Container item)
            {
                return item == null || item.isDestroy;
            }

        }
    }

    public class Loop : System<ISystem>, INoLife
    {
        static private bool _isRuning = false;
        static private ulong _frame = 0;
        static private float _time = 0f;
        static private int _ms = 0;
        static private float _runingtime = 0;
        static private long _runingMtime = 0;


        public static int ms { get { return _ms; } }
        public static float time { get { return _time; } }
        public static bool isRuning { get { return _isRuning; } }
        public static ulong frame { get { return _frame; } }
        //public static float runingtime { get { return _runingtime; } }
        public static long runingMtime { get { return _runingMtime; } }
        public static int fixedtime { get; set; }

        public event Action OnUpdateEnd;

        public event Func<bool> OnFrameEnd;

        public int scale = 1;

        private int _loopCount;

        public static ulong netFrame;

        /// <summary>
        /// 是否需要快速追帧
        /// </summary>
        public static bool NeedFast;

        public override void Update(float time)
        {
            _time = time;
            _isRuning = true;
            _loopCount = scale;
            _ms = UnityEngine.Mathf.RoundToInt(_time * 1000);//_time.FR2I(); command by daili.ou
            do
            {
                _frame++;
                //UnityEngine.Debug.Log($"<color=white>frame:{_frame} netFrame:{netFrame}</color>");
                _runingtime += _time;
                _runingMtime += _ms;
                base.Update(time);

            } while (ContinueUpdate());

            //OnUpdateEnd?.Invoke();
        }

        protected override void Update(float time, ISystem component)
        {
            if (component != null) component.Update(time);
        }

        protected override void OnDestroy()
        {
            _isRuning = false;
        }

        protected virtual bool ContinueUpdate()
        {
            _loopCount--;

            bool fastMode = (OnFrameEnd == null) ? false : OnFrameEnd.Invoke();

            //不希望追帧跨多了步子

            return _loopCount > 0 && scale > 1 && fastMode;


        }
    }

    #endregion

    #region Entity
    public partial class Entity : Emitter, IRelease, IEntity, IEquatable<Entity>
    {
        enum EState
        {
            None,
            Create,
            Awake,
            Start,
            Destroy,
            Process,
        }

        private EState _state = EState.None;
        private readonly bool _isSystem;
        private bool _allowUpdate = false;

        private bool _enable;
        private bool _isAwake;
        private bool _isStart;
        private bool _isDestroy;
        private ISystem _container;

        protected virtual bool allowUpdate { get { return _allowUpdate; } set { _allowUpdate = value; } }

        public bool enable
        {
            get
            {
                return _enable;
            }
            set
            {
                if (_enable != value)
                {
                    _enable = value;
                    if (_isAwake)
                    {
                        if (_enable) OnEnable();
                        else OnDisable();
                    }
                }
            }
        }

        public bool isAwake { get { return _isAwake; } }
        public bool isStart { get { return _isStart; } }
        public bool isDestroy { get { return _isDestroy; } }

        public ISystem container
        {
            get { return _container; }
            set
            {
                if (_container != value)
                {
                    if (_container == null || OnContainerChange(value))
                        _container = value;
                }
            }
        }

        public Entity()
        {
            _enable = true;
            _isSystem = this is ISystem;
            _state = EState.Create;

            if (this is INoLife) return;

            _container = Singleton<LifeMgr>.Inst;
            _container.AddItem(this);
        }

        #region Life

        protected virtual void Awake() { }

        protected virtual void OnEnable() { }

        protected virtual void Start() { }

        protected virtual void Update(float time) { }

        protected virtual void LastUpdate(float time) { }

        protected virtual void OnDisable() { }

        protected virtual void OnDestroy() { }

        protected virtual bool CheckCanUpdate()
        {
            return true;
        }

        protected virtual bool OnContainerChange(ISystem system)
        {
            return system == null || _container == null || _container is LifeMgr;
        }

        private bool CanUpdate()
        {
            return (!_isSystem) && allowUpdate && CheckCanUpdate();
        }

        public void Release()
        {
            Destroy(this);
        }

        public bool Equals(Entity other)
        {
            return other != null && other.code == code;
        }

        public virtual void EntityRefresh() { }

        #endregion Life

        #region Static

        static public bool immDestroy = false;

        static private void RealDestory(Entity component)
        {
            if (component != null)
            {
                if (!(component is LifeMgr))
                    Singleton<LifeMgr>.Inst.DelItem(component);
                component.OnDestroy();
                component.container = null;
                component.Clear();
                component._isAwake = false;
                component._isStart = false;
                component._enable = false;
                component._state = EState.None;
                component._isDestroy = false;
            }
        }

        static public void Destroy(Entity component, bool imm = false)
        {
            if (component != null && !component._isDestroy)
            {
                component._isDestroy = true;
                component._state = EState.Destroy;
                if (imm || immDestroy) RealDestory(component);
            }
        }

        static public void Quit()
        {
            Destroy(Singleton<LifeMgr>.Inst);
            Singleton<LifeMgr>.Inst.Update(0);
            Singleton<LifeMgr>.Release();
        }

        public static implicit operator bool(Entity exists)
        {
            return exists != null && !exists.isDestroy && exists._state > 0;
        }


        #endregion Static

        class LifeMgr : ESystem<Entity>, INoLife
        {
            private readonly List<Entity> _awakes = new List<Entity>();
            private readonly List<Entity> _starts = new List<Entity>();
            private readonly List<Entity> _lateUpdates = new List<Entity>();
            private readonly List<Entity> _destroys = new List<Entity>();

            protected override bool noFilter => true;

            public override void Update(float time)
            {
                base.Update(time);
                Awake();
                Start();
                LastUpdate(time);
                OnDestroy();
            }

            protected override void Update(float time, Entity component)
            {
                if (component != null && (component._isDestroy || (component._enable && component._container != null)))
                {
                    if (component._isDestroy || _isDestroy)
                        _destroys.Add(component);
                    else if (component._state < EState.Process || component.CanUpdate())
                    {
                        if (!component._isAwake)
                        {
                            if (!_awakes.Contains(component)) _awakes.Add(component);
                        }
                        else if (!component._isStart)
                        {
                            if (!_starts.Contains(component)) _starts.Add(component);
                        }
                        else
                        {
                            component.Update(time);
                            _lateUpdates.Add(component);
                        }
                    }
                }
            }

            protected override void LastUpdate(float time)
            {
                if (_lateUpdates.Count > 0)
                {
                    int l = _lateUpdates.Count;
                    for (int i = 0; i < l; i++)
                    {
                        var c = _lateUpdates[i];
                        if (c != null && c.enable)
                            c.LastUpdate(time);
                    }
                    _lateUpdates.Clear();
                }
            }

            protected override void Awake()
            {
                if (_awakes.Count > 0)
                {
                    int l = _awakes.Count;
                    for (int i = 0; i < l; i++)
                    {
                        var c = _awakes[i];
                        if (c != null && c.enable)
                        {
                            c._state = EState.Awake;
                            c._enable = false;
                            c._isAwake = true;
                            c.Awake();
                            c.enable = true;
                        }
                    }
                }
                _awakes.Clear();
            }

            protected override void Start()
            {
                if (_starts.Count > 0)
                {
                    int l = _starts.Count;
                    for (int i = 0; i < l; i++)
                    {
                        _starts[i]._state = EState.Start;
                        _starts[i].Start();
                        _starts[i]._isStart = true;
                        _starts[i]._state = EState.Process;
                    }
                }
                _starts.Clear();
            }

            protected override void OnDestroy()
            {
                if (_isDestroy)
                {
                    var cs = GetComponents();
                    foreach (var v in cs) Destroy(v, true);
                    cs.Clear();
                    Clear();
                }
                else
                {
                    if (_destroys.Count > 0)
                    {
                        int l = _destroys.Count;
                        for (int i = 0; i < l; i++)
                        {
                            var c = _destroys[i];
                            RealDestory(c);
                        }
                    }
                }
                _destroys.Clear();
            }
        }
    }

    #endregion
}
