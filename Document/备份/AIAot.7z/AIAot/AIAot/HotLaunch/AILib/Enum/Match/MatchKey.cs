using System;
using AI.FSM.Auto;

namespace AI
{
    public static class MatchKey
    {
        /// <summary>
        /// ������С��
        /// </summary>
        public const string period = "period";
        /// <summary>
        /// ��ǰʣ��ʱ��
        /// </summary>
        public const string overtime = "overtime";
        public const string matchState = "matchState";
        public const string overTStr = "overTStr";
        public const string matchSetting = "matchSetting";
        public const string matchRound = "matchRound";
        public const string matchStageRound = "matchStageRound";
        public const string matchStateArgs = "matchStateArgs";

        /// <summary>
        /// ��Ȩ��Ա
        /// </summary>
        public const string owner = "owner";
        /// <summary>
        /// ��Ȩ����
        /// </summary>
        public const string ownerTeam = "ownerteam";
        public const string ownerUniqid = "owneruniqid";
        /// <summary>
        /// �����Ա״̬
        /// </summary>
        public const string ownerState = "ownerstate";
        /// <summary>
        /// �����Ա״̬����
        /// </summary>
        public const string ownerStateMatch = "ownerstateMatch";

        /// <summary>
        /// ��ͣ
        /// </summary>
        public const string pause = "pause";
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public const string actTime = "actTime";
        /// <summary>
        /// �÷ֶ���
        /// </summary>
        public const string fireTeam = "fireTeam";
        public const string firePos = "firePos";

        public const string rightScore = "rightScore";
        public const string leftScore = "leftScore";
        public const string ballState = "ballState";
        public const string foul = "foul";
        public const string foulType = "foulType";
        public const string foulState = "foulState";
        public const string goal = "goal";

        public const string servePlayers = "servePlayers";

        public const string dealBall = "dealBall";

        public const string changePos = "changePos";
        public const string initState = "initState";
        public const string forbidChange = "forbidChange";
        public const string allFree = "allFree";

        public const string ballFly = "ballFly";
        public const string ballFlyState = "ballFlyState";
        public const string ballReachTop = "ballReachTop";
        public const string ballHitFloor = "ballHitFloor";
        public const string ballCanBeCatch = "ballCanBeCatch";
        public const string ballNoHSpeed = "ballNoHSpeed";

        /// <summary>
        /// ������
        /// </summary>
        public const string playerHandDir = "playerHandDir";
        /// <summary>
        /// ��������
        /// 1 �������������
        /// 2 �����ұ�
        /// -1 �Է��������
        /// -2 �Է������ұ�
        /// </summary>
        public const string playerArea = "playerArea";
        public const string playerAttackArea = "playerAttackArea";
        public const string playerBackMoveRotation = "playerBackMoveRotation";

        public const string skillArgs = "skillOtherArgs";
        public const string skill_SurroundingsCondition = "skill_SurroundingsCondition";
        public const string skill_SlefStateCondition = "skill_SlefStateCondition";
        public const string skill_TargetStateCondition = "skill_TargetStateCondition";
        public const string skill_SlefSkillCondition = "skill_SlefSkillCondition";
        public const string skill_HandednessCondition = "skill_HandednessCondition";
        public const string skill_ReboundSkillFrameKeyBallPos = "ReboundSkillFrameKeyBallPos";

        public const string slefIsholdPlayer = "slefIsholdPlayer";
        public const string rebounder = "rebounder";
        public const string crushed = "crushed";


        public readonly static uint periodID = period.ToID();
        public readonly static uint overtimeID = overtime.ToID();
        public readonly static uint matchStateID = matchState.ToID();
        public readonly static uint overTStrID = overTStr.ToID();
        public readonly static uint matchSettingID = matchSetting.ToID();
        public readonly static uint matchRoundID = matchRound.ToID();
        public readonly static uint matchStageRoundID = matchStageRound.ToID();
        public readonly static uint matchStateArgsID = matchStateArgs.ToID();

        public readonly static uint ownerID = owner.ToID();
        public readonly static uint pauseID = pause.ToID();
        public readonly static uint ownerTeamID = ownerTeam.ToID();
        public readonly static uint ownerStateID = ownerState.ToID();
        public readonly static uint ownerUniqidID = ownerUniqid.ToID();
        public readonly static uint ownerStateMatchID = ownerStateMatch.ToID();

        public readonly static uint actTimeID = actTime.ToID();
        public readonly static uint fireTeamID = fireTeam.ToID();
        public readonly static uint firePosID = firePos.ToID();

        public readonly static uint rightScoreID = rightScore.ToID();
        public readonly static uint leftScoreID = leftScore.ToID();
        public readonly static uint ballStateID = ballState.ToID();
        public readonly static uint foulID = foul.ToID();
        public readonly static uint foulTypeID = foulType.ToID();
        public readonly static uint foulStateID = foulState.ToID();
        public readonly static uint goalID = goal.ToID();

        public readonly static uint servePlayersID = servePlayers.ToID();

        public readonly static uint dealBallID = dealBall.ToID();
        public readonly static uint changePosID = changePos.ToID();
        public readonly static uint initStateID = initState.ToID();
        public readonly static uint forbidChangeID = forbidChange.ToID();
        public readonly static uint allFreeID = allFree.ToID();

        public readonly static uint ballFlyID = ballFly.ToID();
        public readonly static uint ballFlyStateID = ballFlyState.ToID();
        public readonly static uint ballReachTopID = ballReachTop.ToID();
        public readonly static uint ballHitFloorID = ballHitFloor.ToID();
        public readonly static uint ballCanBeCatchID = ballCanBeCatch.ToID();
        public readonly static uint ballNoHSpeedID = ballNoHSpeed.ToID();

        public readonly static uint playerHandDirID = playerHandDir.ToID();
        public readonly static uint playerAreaID = playerArea.ToID();
        public readonly static uint playerAttackAreaID = playerAttackArea.ToID();
        public readonly static uint playerBackMoveRotationID = playerBackMoveRotation.ToID();

        public readonly static uint skillArgsID = skillArgs.ToID();
        public readonly static uint skill_SurroundingsConditionID = skill_SurroundingsCondition.ToID();
        public readonly static uint skill_SlefStateConditionID = skill_SlefStateCondition.ToID();
        public readonly static uint skill_TargetStateConditionID = skill_TargetStateCondition.ToID();
        public readonly static uint skill_SlefSkillConditionID = skill_SlefSkillCondition.ToID();
        public readonly static uint skill_HandednessConditionID = skill_HandednessCondition.ToID();
        public readonly static uint skill_ReboundSkillFrameKeyBallPosID = skill_ReboundSkillFrameKeyBallPos.ToID();

        public readonly static uint selfIsHoldPlayerID = slefIsholdPlayer.ToID();
        public readonly static uint rebounderID = rebounder.ToID();
        public readonly static uint crushedID = crushed.ToID();





        public const string rollBack = "matchRollBack";
        public static uint rollBackID = rollBack.ToID();
    }
}