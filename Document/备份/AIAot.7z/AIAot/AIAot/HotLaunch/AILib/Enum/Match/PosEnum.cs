namespace AI
{

    public enum PosEnum : int
    {
        Net = -5,
        BasketballStands = -4,
        Goal = -3,
        Rebound = -2,
        Rim = -1,
        Ball = 0,
        __PG = 1,
        PG = 1,
        SG,
        SF,
        PF,
        C,
    }

}
