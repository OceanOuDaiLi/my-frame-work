﻿using System;
using AI.FSM.Auto;

namespace AI
{
    [Flags]
    public enum MatchStateEnum
    {
        #region 定义阶段
        /// <summary>
        /// 准备阶段
        /// </summary>
        Ready = 1 << 0,
        /// <summary>
        /// 跳球
        /// </summary>
        Jump = 1 << 1,
        /// <summary>
        /// 对抗阶段
        /// </summary>
        [Condition(leftID = (int)Serve, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]  //发球结束
        [Condition(MatchKey.owner, 0, false, TypeCode.Int32, Lib.P.CompareOp.Greater)]//获得球权
        Rivalry = 1 << 2,
        /// <summary>
        /// 篮板
        /// </summary>
        Rebound = 1 << 3,
        /// <summary>
        /// 自由球
        /// </summary>
        [Condition(leftID = (int)Rebound, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]  //篮板结束
        [Condition(MatchKey.owner, 0, false, TypeCode.Int32, Lib.P.CompareOp.Greater)]//没有球权
        Freeball = 1 << 4,
        /// <summary>
        /// 发球
        /// </summary>
        Serve = 1 << 5,
        /// <summary>
        /// 罚球
        /// </summary>
        Foul = 1 << 6,
        /// <summary>
        /// 暂停
        /// </summary>
        Pause = 1 << 7,
        /// <summary>
        /// 换人
        /// </summary>
        [Condition(MatchKey.changePos, 0, false, TypeCode.Int32, Lib.P.CompareOp.Greater)]
        [Condition(MatchKey.dealBall, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)]
        //[Condition(MatchKey.forbidChange, true, false, TypeCode.Boolean, Lib.P.CompareOp.NotEq)]
        [Condition(left = MachineConst.C_STATE_ENTER_STR, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.NotEq)]
        Change = 1 << 8,

        /// <summary>
        /// 庆祝
        /// </summary>
        Celebrate = 1 << 15,
        StageStart = 1 << 16,
        /// <summary>
        /// 小节结束
        /// </summary>
        [Condition(MatchKey.ballFlyState, false, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)]     //球不处于飞行状态   
        [Condition(MatchKey.ownerState, (int)Object.PlayerStateEnum.__Skill, false, TypeCode.Int32, Lib.P.CompareOp.Greater, otherCompare = 2)]
        [Condition(MatchKey.overtime, 0f, false, TypeCode.Single, Lib.P.CompareOp.LEq)]         //单节时间结束
        [Condition(MatchKey.period, 1, false, TypeCode.Int32, Lib.P.CompareOp.GEq)]             //比赛已经开始
        [Condition(left = MachineConst.C_STATE_KEY_STR, right = (int)Celebrate, type = TypeCode.Int32, compare = Lib.P.CompareOp.LEq)]  //不处于结束
        [Condition(left = MachineConst.C_STATE_KEY_STR, right = (int)Foul, type = TypeCode.Int32, compare = Lib.P.CompareOp.NotEq)]  //不处于罚球
        [Condition(left = MachineConst.C_STATE_KEY_STR, right = (int)Serve, type = TypeCode.Int32, compare = Lib.P.CompareOp.NotEq)]  //不处于罚球
        [Condition(MatchKey.foul, 0, false, TypeCode.Int32, Lib.P.CompareOp.LEq)]
        StageFinish = 1 << 17,
        /// <summary>
        /// 结束
        /// </summary>
        MatchFinish = 1 << 18,
        /// <summary>
        /// 强制结束
        /// </summary>
        ForceFinish = 1 << 19,
        /// <summary>
        /// 发球前置状态
        /// </summary>
        PreServe = 1 << 20,
        //=================================
        /// <summary>
        /// 回滚
        /// </summary>
        RollBack = 1 << 30,
        #endregion

        #region 阶段转换

        /*[Condition(leftID = (int)Ready, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        [Condition(MatchKey.period, (int)MatchPeriodEnum.One, false, TypeCode.Int32, Lib.P.CompareOp.Greater)]
        r2serve = Ready | Serve, //如果跳过前几节,则从发球开始*/

        [Condition(MatchKey.owner, 0, false, TypeCode.Int32, Lib.P.CompareOp.Greater)]
        [Condition(leftID = (int)Jump, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        j2r = Jump | Rivalry,   //跳球结束进入对抗

        [Condition(MatchKey.foul, 0, false, TypeCode.Int32, Lib.P.CompareOp.Greater)]
        [Condition(MatchKey.ownerState, (int)Object.PlayerStateEnum.__Skill, false, TypeCode.Int32, Lib.P.CompareOp.Greater, otherCompare = 2)]
        [Condition(MatchKey.ballFlyState, false, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)]
        r2f = Rivalry | Foul,//罚球

        [Condition(MatchKey.pause, 0, false, TypeCode.Int32, Lib.P.CompareOp.NotEq)]                                //有队伍请求暂停
        [Condition(MatchKey.pause, MatchKey.ownerTeam, true, TypeCode.Int32, Lib.P.CompareOp.Eq)]                   //暂停队伍获得球权
        [Condition(MatchKey.owner, 0, true, TypeCode.Int32, Lib.P.CompareOp.Greater)]
        [Condition(MatchKey.ownerState, (int)Object.PlayerStateEnum.__Skill, false, TypeCode.Int32, Lib.P.CompareOp.Greater, otherCompare = 2)]
        //[Condition(leftID = (int)Rivalry, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]     //对抗结束
        //[Condition(MatchKey.ballState, (int)Object.BallStateEnum.Floor, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]                                //有队伍请求暂停
        r2p = Rivalry | Pause,

        [Condition(MatchKey.pause, 0, false, TypeCode.Int32, Lib.P.CompareOp.NotEq)]                                //有队伍请求暂停
        [Condition(leftID = (int)Rivalry, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]     //对抗结束
        [Condition(MatchKey.ballState, (int)Object.BallStateEnum.Floor, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]                                //有队伍请求暂停
        r2p2 = Rivalry | Pause,

        [Condition(MatchKey.pause, 0, false, TypeCode.Int32, Lib.P.CompareOp.NotEq)]
        [Condition(leftID = (int)Foul, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]     //罚球结束
        [Condition(MatchKey.ballState, (int)Object.BallStateEnum.Floor, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]                                //有队伍请求暂停
        f2p = Foul | Pause,

        [Condition(MatchKey.foul, 0, false, TypeCode.Int32, Lib.P.CompareOp.LEq)]
        [Condition(MatchKey.pause, 0, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]
        [Condition(MatchKey.ballState, (int)AI.Object.BallStateEnum.Floor, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]     //球不处于投篮状态
        [Condition(MatchKey.overtime, 0f, false, TypeCode.Single, Lib.P.CompareOp.Greater)]
        [Condition(MatchKey.allFree, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)] //所有球员处于空闲
        [Condition(leftID = (int)Rivalry, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        r2s = Rivalry | PreServe,

        [Condition(MatchKey.period, (int)MatchPeriodEnum.Four, false, TypeCode.Int32, Lib.P.CompareOp.GEq)]
        [Condition(MatchKey.rightScore, MatchKey.leftScore, true, TypeCode.Int32, Lib.P.CompareOp.NotEq)]
        [Condition(leftID = (int)StageFinish, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        s2e = StageFinish | MatchFinish, //比赛结束

        p2s = (Pause | PreServe),//暂停完发球

        [Condition(MatchKey.pause, 0, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]
        [Condition(MatchKey.foulState, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)]
        [Condition(MatchKey.ballState, (int)Object.BallStateEnum.Floor, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]
        [Condition(MatchKey.overtime, 0f, false, TypeCode.Single, Lib.P.CompareOp.Greater)]
        [Condition(leftID = (int)Foul, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        f2s = (Foul | PreServe),//罚球完发球

        [Condition(MatchKey.pause, 0, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]
        [Condition(MatchKey.foulState, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)]
        [Condition(MatchKey.overtime, 0f, false, TypeCode.Single, Lib.P.CompareOp.Greater)]
        [Condition(leftID = (int)Foul, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        f2r = -(Foul | Rivalry),//罚球结束转对抗

        [Condition(MatchKey.pause, 0, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]
        [Condition(MatchKey.foulState, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)]
        //[Condition(MatchKey.ballState, (int)Object.BallStateEnum.Floor, false, TypeCode.Int32, Lib.P.CompareOp.Eq)]
        [Condition(MatchKey.ballFlyState, false, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)]     //球不处于飞行状态   
        [Condition(MatchKey.overtime, 0f, false, TypeCode.Single, Lib.P.CompareOp.LEq)]
        [Condition(leftID = (int)Foul, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        f2sf = Foul | StageFinish,//罚球结束转小节结束

        ff2mf = -(ForceFinish | MatchFinish),//强制结束转结束收尾

        [Condition(leftID = (int)Ready, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        read2ss = Ready | StageStart,//准备转开始

        [Condition(MatchKey.period, (int)MatchPeriodEnum.One, false, TypeCode.Int32, Lib.P.CompareOp.LEq)]
        [Condition(leftID = (int)StageStart, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        ss2j = -(StageStart | Jump),//跳球开始

        [Condition(MatchKey.period, (int)MatchPeriodEnum.One, false, TypeCode.Int32, Lib.P.CompareOp.Greater)]
        [Condition(leftID = (int)StageStart, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        ss2se = (StageStart | PreServe),//发球开始

        [Condition(MatchKey.period, (int)MatchPeriodEnum.Four, false, TypeCode.Int32, Lib.P.CompareOp.Less)]
        [Condition(leftID = (int)StageFinish, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        ps2s = -(StageFinish | StageStart),//小节结束转开始

        [Condition(MatchKey.period, (int)MatchPeriodEnum.Four, false, TypeCode.Int32, Lib.P.CompareOp.GEq)]
        [Condition(MatchKey.rightScore, MatchKey.leftScore, true, TypeCode.Int32, Lib.P.CompareOp.Eq)]
        [Condition(leftID = (int)StageFinish, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        ps2s_2 = -(StageFinish | StageStart),//加时赛结束转开始

        pres2s = -(PreServe | Serve),

        #endregion

        #region Other
        __DeadBall = Serve | Pause | PreServe,
        __StopState = Ready | Pause | Jump | Serve | StageFinish | Foul | Change | Celebrate | ForceFinish | StageStart | RollBack | PreServe,
        __NOFace = Ready | Pause | Jump | Serve | StageFinish | Change | Celebrate | ForceFinish | StageStart | RollBack | PreServe,
        #endregion

    }
}
