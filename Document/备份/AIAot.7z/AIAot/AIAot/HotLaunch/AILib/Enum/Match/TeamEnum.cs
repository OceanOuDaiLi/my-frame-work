namespace AI
{

    public enum TeamEnum
    {
        OB = -1,
        Ball = 0,
        Left = 1,
        Right = 2,
    }
  
}
