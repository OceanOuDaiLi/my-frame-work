﻿using Library.Interface.IO;
using Library.IO;
using System;
using System.Collections;
using UnityEngine.Networking;

namespace Zeus.Launch
{
    public partial class HotLaunch
    {
        bool _gotNeedUpdateTxt { get; set; }
        bool _gotServerVersion { get; set; }

        IEnumerator RequestGet(string downloadPath, Action<byte[]> response)
        {
            LogProgress("Web Request: " + downloadPath);
            using (var request = UnityWebRequest.Get(downloadPath))
            {
                UnityWebRequestAsyncOperation webRequestOp = request.SendWebRequest();

                yield return webRequestOp;

                while (!webRequestOp.isDone) { yield return null; }

                if (!request.result.Equals(UnityWebRequest.Result.Success))
                {
                    LogProgress("[HotLaunch.Net] => Request download error. with Path " + downloadPath);
                    response?.Invoke(null);
                }
                else
                {
                    response?.Invoke(request.downloadHandler.data);
                }
            }
        }

        private void ResponseGetClrResHost(byte[] result)
        {
            try
            {
                _resUrl = System.Text.Encoding.UTF8.GetString(result);
                _resUrl = _resUrl.Trim();
                getResUrl = true;
            }
            catch (Exception e)
            {
                LogProgress("[HotLaunch.Net] => Request download error. e: " + e);
                OnNetError();
            }
        }

        private void ResponseGetServerVersion(byte[] result)
        {
            if (_gotServerVersion) { return; }

            try
            {
                //cached result
                clrVerBytes = result;

                /*
                 * Kings2 不对配置相关的文件进行加密
                //temporary decrypted
                LocalDisk disk = new LocalDisk("", IOHelper.IOCrypt);
                byte[] data = disk.IOCrypt.Decrypted(result);
                */
                _serverVer = System.Text.Encoding.UTF8.GetString(result);
                _gotServerVersion = true;
            }
            catch (Exception e)
            {
                LogProgress("[HotLaunch.Net] => Request download error. e: " + e);
                OnNetError();
            }
        }


        private void ResponseDownloadAotDlls(byte[] result)
        {
            try
            {
                downloadedSize += aotUpdateInfo.fileByteSize;
                SetDownloadText();

                aotDllBytes = result;
                _downLoadList.Remove(_aotDllsUrl);
            }
            catch (Exception e)
            {
                LogProgress("[HotLaunch.Net] => Request download error. e: " + e);
                OnNetError();
            }
        }

        void ResponseDownloadHotDlls(byte[] result)
        {
            try
            {
                downloadedSize += hotUpdateInfo.fileByteSize;
                SetDownloadText();

                hotDllBytes = result;
                _downLoadList.Remove(_hotDllsUrl);
            }
            catch (Exception e)
            {
                LogProgress("[HotLaunch.Net] => Request download error. e: " + e);
                OnNetError();
            }
        }

        void ResponseDownloadNeedUpdateList(byte[] result)
        {
            try
            {
                needUpdateInfos = new System.Collections.Generic.List<UpdateInfo>();

                string updateInfo = System.Text.Encoding.UTF8.GetString(result);
                string[] serverParseArr = updateInfo.Split(';');

                System.Collections.Generic.List<UpdateInfo> serverUpdateInfos = new System.Collections.Generic.List<UpdateInfo>();
                System.Collections.Generic.List<UpdateInfo> localUpdateInfos = new System.Collections.Generic.List<UpdateInfo>();
                for (int i = 0; i < serverParseArr.Length; i++)
                {
                    serverUpdateInfos.Add(ParseString(serverParseArr[i]));
                }

                //get local hotlist
                IDirectory _destDir = PersistentDisk.Directory();
                _destDir = PersistentDisk.Directory();

                _localHotFile = _destDir.File(hotlistFileName);
                if (_localHotFile.Exists)
                {
                    string localUpdateInfo = System.Text.Encoding.UTF8.GetString(_localHotFile.Read());
                    string[] localParseArr = localUpdateInfo.Split(';');
                    for (int i = 0; i < localParseArr.Length; i++)
                    {
                        localUpdateInfos.Add(ParseString(localParseArr[i]));
                    }
                    //compare need update info
                    for (int i = 0; i < localUpdateInfos.Count; i++)
                    {
                        var localInfo = localUpdateInfos[i];
                        var serverInfo = serverUpdateInfos.Find((x) => { return x.fileName.Equals(localInfo.fileName); });

                        if (!serverInfo.fileMd5.Equals(localInfo.fileMd5))
                        {
                            needUpdateInfos.Add(serverInfo);
                        }
                    }
                }
                else
                {
                    needUpdateInfos = serverUpdateInfos;
                }

                if (_localHotFile.Exists)
                {
                    _localHotFile.Delete();
                }

                _localHotFile.Create(result);
                _gotNeedUpdateTxt = true;
            }
            catch (Exception e)
            {
                LogProgress("[HotLaunch.Net] => Request download error. e: " + e);
                OnNetError();
            }
        }

        void OnNetError()
        {
            onNetError = true;
            NetTips.SetActive(true);
        }


        UpdateInfo ParseString(string tar)
        {
            string[] firstValue = tar.Split(',');

            UpdateInfo updateInfo = new UpdateInfo();
            for (int i = 0; i < firstValue.Length; i++)
            {
                string[] result = firstValue[i].Split(':');
                if (result[0].Contains("name"))
                {
                    updateInfo.fileName = result[1];
                }
                else if (result[0].Contains("size"))
                {
                    updateInfo.fileByteSize = int.Parse(result[1]);
                }
                else if (result[0].Contains("md5"))
                {
                    updateInfo.fileMd5 = result[1];
                }
                else
                {
                    LogError("Parse HotList.txt error");
                }
            }
            return updateInfo;
        }
    }
}