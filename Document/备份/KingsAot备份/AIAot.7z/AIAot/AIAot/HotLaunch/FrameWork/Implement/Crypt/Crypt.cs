﻿
using Library.Interface.Crypt;

namespace Library.Crypt
{   
    /// <summary>
    /// 加密
    /// </summary>
    public sealed class Crypt : ICrypt
    {
        /// <summary>
        /// 加密算法
        /// </summary>
        private ICryptAdapter adapter;

        /// <summary>
        /// 密钥
        /// </summary>
        private string key;
        private byte[] keyBytes;

        /// <summary>
        /// IV
        /// </summary>
        private string iv;
        private byte[] ivBytes;

        /// <summary>
        /// 设定加密适配器
        /// </summary>
        /// <param name="adapter">适配器</param>
        public void SetAdapter(ICryptAdapter adapter)
        {
            this.adapter = adapter;
        }

        /// <summary>
        /// 设定密钥
        /// </summary>
        /// <param name="key">32位密钥</param>
        public void SetKey(string key)
        {
            if (key.Length != 32) throw new System.Exception("crypt key length must be 32");

            this.key = key;
            this.keyBytes = System.Text.Encoding.UTF8.GetBytes(this.key);
        }

        public void SetIV(string iv)
        {
            this.iv = iv;
            this.ivBytes = System.Convert.FromBase64String(this.iv);

            if (this.ivBytes.Length != 16) throw new System.Exception("crypt iv length must be 16");
        }

        /// <summary>
        /// 加密字符串
        /// </summary>
        /// <param name="str">需要被加密的字符串</param>
        /// <returns>加密后的字符串</returns>
        public byte[] Encrypt(byte[] content)
        {
            if (keyBytes == null || ivBytes == null)
            {
                throw new System.Exception("crypt key or iv is invalid");
            }
            if (adapter == null)
            {
                throw new System.Exception("undefined crypt adapter");
            }
            return adapter.Encrypt(content, keyBytes, ivBytes);
        }

        /// <summary>
        /// 解密被加密的字符串
        /// </summary>
        /// <param name="str">需要被解密的字符串</param>
        /// <returns>解密后的字符串</returns>
        public byte[] Decrypt(byte[] content)
        {
            if (keyBytes == null || ivBytes == null)
            {
                throw new System.Exception("crypt key ov iv is invalid");
            }
            if (adapter == null)
            {
                throw new System.Exception("undefined crypt adapter");
            }
            return adapter.Decrypt(content, keyBytes, ivBytes);
        }
    }
}