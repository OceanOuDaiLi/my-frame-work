﻿using System;
using UnityEngine;
using System.Linq;
using System.Collections;

namespace Zeus.Launch
{
    public partial class HotLaunch : MonoBehaviour
    {
        [SerializeField] UnityEngine.UI.Text text;
        [SerializeField] GameObject NetTips;

        bool onNetError = false;
        public static HotLaunch Instance = null;
        public System.Reflection.Assembly GameAsset { get; private set; }

        [HideInInspector]
        public bool DEBUG_MODEL = false;

        private void Awake()
        {
            Instance = this;
            DontDestroyOnLoad(this);
        }

        void OnApplicationFocus(bool isFocused)
        {
            if (isFocused && onNetError)
                NetTips.SetActive(true);
        }

        private void OnEnable()
        {
            if (onNetError)
                NetTips.SetActive(true);
        }

        public IEnumerator Start()
        {

            enableLog = true;

            DEBUG_MODEL = true;//!Application.isMobilePlatform;

            Debug.Log("[HotLaunch::DEBUG_MODEL] => " + DEBUG_MODEL);

            if (DEBUG_MODEL)
            {
                //enableLog = true;
                yield return SkipCsharpHotFix();
            }
            else
            {
                // step 1: Get local version file.
                bool localFileCheckPass = GetLocalVersion();

                yield return GetTotalPkgInstall();

                // step 2: Checking Version file is existsed.
                if (!localFileCheckPass || totalIntalPkg)
                {
                    //if not existsed,
                    //copyed from streaming assset data path to persistentDataPath
                    yield return CopyStreamingAssets();

                    yield return Start();
                }

                // step 3: Get Urls.
                yield return GetUrls();

                while (!getUrlsDown) { yield return null; }

                // step 4: Get server version file.
                yield return GetServerVersion();

                while (!_gotServerVersion) { yield return null; }

                // step 5: Version Compareing
                if (VersionCompare())
                {
                    //version compare passed, Hot Starting Game.
                    yield return HybridClrStart();
                }
                else
                {
                    ///version compare not passed, Download hot fix dlls.
                    yield return DownloadAndWriteFiles();

                    yield return HybridClrStart();
                }

            }
        }

        public void OnClickRetry()
        {
            NetTips.SetActive(false);
            StopAllCoroutines();
            LogProgress("#### Net Error Retry ####");
            StartCoroutine(Start());
        }

        private IEnumerator HybridClrStart()
        {
            GetClrFile();

            var request = AssetBundle.LoadFromFileAsync(_hotDllFile.FullName);

            while (!request.isDone) { yield return null; }

            AssetBundle dllAB = request.assetBundle;

            byte[] csBytes = dllAB.LoadAsset<TextAsset>("Assembly-CSharp.dll.bytes").bytes;
            LogProgress("csBytes --- len：" + csBytes.Length);
            byte[] sfloatBytes = dllAB.LoadAsset<TextAsset>("sfloat.dll.bytes").bytes;
            LogProgress("sfloatBytes --- len：" + sfloatBytes.Length);
            byte[] smathBytes = dllAB.LoadAsset<TextAsset>("smath.dll.bytes").bytes;
            LogProgress("smathBytes --- len：" + smathBytes.Length);
            byte[] aiMathBytes = dllAB.LoadAsset<TextAsset>("AIMath.dll.bytes").bytes;
            LogProgress("aiMathBytes --- len：" + aiMathBytes.Length);
            byte[] aiConfigBytes = dllAB.LoadAsset<TextAsset>("AIConfig.dll.bytes").bytes;
            LogProgress("aiConfigBytes --- len：" + aiConfigBytes.Length);
            byte[] aiCommonBytes = dllAB.LoadAsset<TextAsset>("AICommon.dll.bytes").bytes;
            LogProgress("aiCommonBytes --- len：" + aiCommonBytes.Length);
            byte[] aiTreeBytes = dllAB.LoadAsset<TextAsset>("AITree.dll.bytes").bytes;
            LogProgress("aiTreeBytes --- len：" + aiTreeBytes.Length);

            LogProgress("Load Assembly Bytes...OK");


            // 先加载依赖的，再加载本体
            //你有A, B, C, D四个dll
            //A需要B，D
            //C需要D
            //那么，加载顺序就是D, C, B, A
            var aiConfigAsset = System.Reflection.Assembly.Load(aiConfigBytes);
            LogProgress("Load Asset --- aiConfigAsset is null : " + (aiConfigAsset == null).ToString());

            var sfloatAsset = System.Reflection.Assembly.Load(sfloatBytes);
            LogProgress("Load Asset --- sfloatAsset is null : " + (sfloatBytes == null).ToString());

            var smathAsset = System.Reflection.Assembly.Load(smathBytes);
            LogProgress("Load Asset --- smathAsset is null : " + (smathBytes == null).ToString());

            var aiMathAsset = System.Reflection.Assembly.Load(aiMathBytes);
            LogProgress("Load Asset --- aiMathAsset is null : " + (aiMathBytes == null).ToString());

            var aiCommonAsset = System.Reflection.Assembly.Load(aiCommonBytes);
            LogProgress("Load Asset --- aiCommonAsset is null : " + (aiCommonBytes == null).ToString());

            var aiTreeAsset = System.Reflection.Assembly.Load(aiTreeBytes);
            LogProgress("Load Asset --- aiTreeAsset is null : " + (aiTreeBytes == null).ToString());

            GameAsset = System.Reflection.Assembly.Load(csBytes);
            LogProgress("Load Asset --- gameAsset is null : " + (csBytes == null).ToString());

            LogProgress("Load Assembly Asset...OK");


            var appType = GameAsset.GetType("FTX.Application.Main");
            if (appType == null)
            {
                LogError("[HotLaunch::HotFixStart] appType is null");
                yield break;
            }

            var mainMethod = appType.GetMethod("HotFixStart");
            if (mainMethod == null)
            {
                LogError("[HotLaunch::RunDll] HotFixStart is null");
                yield break;
            }

            mainMethod.Invoke(null, new object[] { _aotDllFile.FullName });
        }

        private IEnumerator SkipCsharpHotFix()
        {
            System.Reflection.Assembly cSharp = null;
            cSharp = AppDomain.CurrentDomain.GetAssemblies().First(assembly => assembly.GetName().Name == "Assembly-CSharp");
            System.Type appType = cSharp.GetType("FTX.Application.Main");

            yield return null;

            var mainMethod = appType.GetMethod("HotFixStart");
            if (mainMethod == null)
            {
                UnityEngine.Debug.LogError($"[HotLaunch::SkipCsharpHotFix] Main is null");
                yield break;
            }

            mainMethod.Invoke(null, new object[] { "" });

            OnDispose();
        }

        private void OnDispose()
        {
            if (_downLoadList != null)
            {
                _downLoadList.Clear();
                _downLoadList = null;
            }

            if (text != null)
            {
                text = null;
            }
        }
    }
}