namespace AI
{
    public interface IRelease
    {
        void Release();
    }
}