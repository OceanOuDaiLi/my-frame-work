﻿namespace AI.FSM
{

    public interface IDataSet
    {
        void SetVal(uint key, object val = null);

        void Set<T>(uint key, T val = default(T));

        void Set<T>(uint key, System.Func<uint, T> get, System.Action<uint, T> set);

        T Get<T>(uint key, T val = default(T));

        object GetVal(uint key, object val = null);

        void Clear();

        IDataSet Del(uint key);

        bool Has(uint key);

        bool Has<T>(uint key);

        IDataSet UpValue(bool state, IDataSet upvalue);
    }

}
