﻿using System;
using System.Collections.Generic;
using Lib.P;

namespace AI.FSM.Auto
{

    public class MachineConst
    {
        /// <summary>
        /// 当前状态
        /// </summary>
        public const string C_STATE_KEY_STR = "__c_state_key__";
        public readonly static uint C_STATE_KEY_ID = C_STATE_KEY_STR.ToID();

        /// <summary>
        /// 当前状态是否标记
        /// </summary>
        public const string C_STATE_MARKER_STR = "__c_state_marked__";
        public readonly static uint C_STATE_MARKER_ID = C_STATE_MARKER_STR.ToID();

        public const string C_UPVALUE_STR = "__up_value__";
        public readonly static uint C_UPVALUE_ID = C_UPVALUE_STR.ToID();

        public const string C_STATE_ENTER_STR = "__c_state_enter__";            //Aot MatchStateEnum 直接使用的字符串值，要拓展的话，不能改此字符串的值。 add by daili.ou
        public readonly static uint C_STATE_ENTER_ID = C_STATE_ENTER_STR.ToID();
    }


    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Class | AttributeTargets.Property, AllowMultiple = true)]
    public class ConditionAttribute : Attribute
    {
        public ConditionAttribute() { }

        public ConditionAttribute(string left, object right, bool isRef, TypeCode rCode, CompareOp compare)
        {
            this.left = left;
            this.right = right;
            this.type = rCode;
            this.compare = compare;
            this.isRef = isRef;
        }

        public ConditionAttribute(string left, object right, bool isRef, TypeCode rCode, CompareOp compare, int ext)
            : this(left, right, isRef, rCode, compare)
        {
            this.ext = ext;
        }

        public ConditionAttribute(string left, object right, bool isRef, TypeCode rCode, CompareOp compare, int ext, int layer)
            : this(left, right, isRef, rCode, compare)
        {
            this.layer = layer;
        }

        public int id { get; set; }

        public string left { get; set; }

        public uint leftID { get; set; }

        public object right { get; set; }

        public bool isRef { get; set; }

        public TypeCode type { get; set; }

        public CompareOp compare { get; set; }

        public int ext { get; set; }

        public int layer { get; set; } = -1;

        public string arg { get; set; }

        /// <summary>
        /// 扩展compare
        /// </summary>
        public int otherCompare { get; set; }

    }

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Class | AttributeTargets.Property, AllowMultiple = true)]
    public class LinkAttribute : Attribute
    {
        public int link { get; set; }

        public string left { get; set; }

        public uint leftID { get; set; }

        public object right { get; set; }

        public bool isRef { get; set; }

        public TypeCode type { get; set; }

        public CompareOp compare { get; set; }

        public string arg { get; set; }

    }

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Class | AttributeTargets.Property, AllowMultiple = false)]
    public class TransitionAttribute : Attribute
    {

        public int src { get; set; }

        public int dst { get; set; }

        public TransitionAttribute(int src, int dst)
        {

            this.src = src;
            this.dst = dst;

        }

    }

    public class Transition : SwitchList<Pipeline, IDataSet>
    {
        public int source;
        public int target;

        public override Pipeline Add<T>(int key)
        {
            return new Pipeline() { state = target };
        }
    }

    public class Pipeline : SwitchList<Condition, IDataSet>
    {
        public int state;
        public IParameter arg;

        public override Condition Add<T>(int key)
        {
            return new Condition();
        }

        public override bool Call(IDataSet data)
        {
            var s = true;
            if (Count > 0)
            {
                for (int i = 0; i < Count; i++)
                {
                    var c = this[i];
                    if (c.Check(data)) s = s && c.Call(data);
                    if (!s) break;
                }
            }
            return s;
        }

        public override void Reset()
        {
            base.Reset();
            arg?.Release();
        }

    }

    public class Condition : ISwitchCall<IDataSet>
    {
        public const string C_UPVALUE_STR = "__up_value__";
        public readonly static uint C_UPVALUE_ID = Lib.Crc.CRC32.CRC(C_UPVALUE_STR);
        public static Func<Condition, bool> OnOtherCompareHandler;

        private IDataSet _data;

        public Lib.P.IParameter p1;
        public Lib.P.IParameter p2;
        public Lib.P.CompareOp compare;
        public int otherCompare;

        public int order { get; set; }
        public int key { get; set; }
        public int upValueLayer { get; set; } = -1;
        public bool result { get; private set; } = true;

        public virtual bool Call(IDataSet data)
        {
            _data = data;
            if (otherCompare > 0 && OnOtherCompareHandler != null) return OnOtherCompareHandler(this);
            result = p1.CompareTo(p2, compare);
            return result;
        }

        public virtual bool Check(IDataSet data)
        {
            return p1 != null && p2 != null;
        }

        public virtual void Reset()
        {
            _data = null;
            p1?.Release();
            p2?.Release();
            p1 = null;
            p1 = null;
        }

        public void Set<T>(string left, T right, Lib.P.CompareOp compare)
        {
            Reset();
            p1 = new Lib.P.Parameter<T>(left, GetValue<T>, SetValue<T>);
            p2 = new Lib.P.Parameter<T>(left, right);
            this.compare = compare;
        }

        public void Set<T>(uint left, T right, Lib.P.CompareOp compare)
        {
            Reset();
            p1 = new Lib.P.Parameter<T>(left, GetValue<T>, SetValue<T>);
            p2 = new Lib.P.Parameter<T>(left, right);
            this.compare = compare;
        }

        public void SetByKey<T>(string left, string right, Lib.P.CompareOp compare)
        {
            Reset();
            p1 = new Lib.P.Parameter<T>(left, GetValue<T>, SetValue<T>);
            p2 = new Lib.P.Parameter<T>(right, GetValue<T>, SetValue<T>);
            this.compare = compare;
        }

        public void SetByKey<T>(uint left, uint right, Lib.P.CompareOp compare)
        {
            Reset();
            p1 = new Lib.P.Parameter<T>(left, GetValue<T>, SetValue<T>);
            p2 = new Lib.P.Parameter<T>(right, GetValue<T>, SetValue<T>);
            this.compare = compare;
        }

        private T GetValue<T>(uint uid)
        {
            if (_data != null)
            {
                if (upValueLayer < 0) return _data.Get<T>(uid);
                else
                {
                    var d = _data;
                    var l = upValueLayer;

                    while ((l > 0 || !d.Has<T>(uid)) && d.Has<IDataSet>(C_UPVALUE_ID))
                    {
                        d = d.Get<IDataSet>(C_UPVALUE_ID);
                        l--;
                    }
                    return d == null ? default(T) : d.Get<T>(uid);
                }
            }
            return default(T);
        }

        private void SetValue<T>(uint uid, T val)
        {
            if (_data != null)
                _data.Set<T>(uid, val);
        }
    }

    public class Processer : SwitchList<Transition, IDataSet>
    {
        private readonly Dictionary<int, Action<IDataSet, int, bool>> _process = new Dictionary<int, Action<IDataSet, int, bool>>();
        protected IDataSet agnet { get; private set; }
        protected int current { get; set; }
        public bool enable { get; set; }
        public bool isInited { get; private set; }
        public bool canSwitchSelf { get; set; }

        public Processer()
        {
            enable = true;
        }

        ~Processer()
        {
            UnInit();
        }

        public void Init()
        {
            if (isInited) return;
            isInited = true;
            OnInit();
        }

        public virtual void SetAgnet(IDataSet agnet)
        {
            this.agnet = agnet;
        }

        public Processer AddProcess(int idx, Action<IDataSet, int, bool> call)
        {
            if (call != null)
            {
                Action<IDataSet, int, bool> c;
                if (_process.TryGetValue(idx, out c))
                {
                    c -= call;
                    c += call;
                }
                else c = call;
                _process[idx] = c;
            }
            return this;
        }

        public Processer DelProcess(int idx, Action<IDataSet, int, bool> call)
        {
            if (call != null)
            {
                Action<IDataSet, int, bool> c = null;
                if (_process.TryGetValue(idx, out c))
                {
                    c -= call;
                    _process[idx] = c;
                }
            }
            return this;
        }

        public void ChangeTo(int idx)
        {
            OnChangeTo(idx);
            current = idx;
        }

        public Transition GetTransition(int s, int t, bool ifMissAdd = true)
        {

            var f = Find((i) => { return i.source == s && i.target == t; });
            if (f == null && ifMissAdd)
            {
                f = Add<Transition>(s);
                f.source = s;
                f.target = t;
                Add(f);
            }
            return f;
        }

        public Transition AddTransition(Transition transition)
        {
            if (transition != null)
            {
                var old = GetTransition(transition.source, transition.target, false);
                if (old == transition) return transition;
                if (old != null)
                {
                    old.AddRange(transition);
                    return old;
                }
                else Add(transition);
                return transition;
            }
            return null;
        }

        public Transition RemoveTransition(int s, int t)
        {
            var trans = GetTransition(s, t, false);
            if (trans != null) RemoveTransition(trans);
            return trans;
        }

        public Processer RemoveTransition(Transition transition)
        {
            if (transition != null)
            {
                if (Contains(transition)) Remove(transition);
            }
            return this;
        }

        public void UnInit()
        {
            if (!isInited) return;
            isInited = false;
            enable = false;
            OnUnInit();
            Reset();
        }

        public override Transition Add<T>(int key)
        {
            return new Transition() { key = key };
        }

        public override bool Call(IDataSet data)
        {
            if (base.Call(data ?? agnet) && select != null)
            {
                ChangeTo(select.target);
            }
            return true;
        }

        protected override bool Check(Transition child)
        {
            return (child.source == current || child.source == 0);
        }

        protected override void OnChecked(Transition child, bool state)
        {
            if (child != null)
            {
                //if (state && child == select) return;
                Action<IDataSet, int, bool> call = null;
                if (_process.TryGetValue(child.target, out call)) call?.Invoke(agnet, child.target, state);
            }
        }

        protected virtual void OnChangeTo(int idx) { }

        protected virtual void OnInit() { }

        protected virtual void OnUnInit() { }

        public override void Reset()
        {
            _process.Clear();
            _pipeline = null;
            agnet = null;
            base.Reset();
        }

        #region method

        private Pipeline _pipeline;

        public int preConditionKey { get; private set; }

        public Processer While(params Condition[] conditions)
        {
            _pipeline = _pipeline ?? new Pipeline();
            _pipeline.AddRange(conditions);
            return this;
        }           //aot ref called  add by daili.ou

        public Processer While<T>(string left, string right, Lib.P.CompareOp compare, int key = 0, int upvalue = -1, int oc = 0)
        {
            if (!string.IsNullOrEmpty(left) && !string.IsNullOrEmpty(right))
            {
                preConditionKey = key == 0 ? (int)Lib.ID.ID.id : key;
                _pipeline = _pipeline ?? new Pipeline();
                var c = _pipeline.Get(preConditionKey);
                c.upValueLayer = upvalue;
                c.otherCompare = oc;
                c.SetByKey<T>(left, right, compare);
            }
            return this;
        }

        public Processer While<T>(uint left, uint right, Lib.P.CompareOp compare, int key = 0, int upvalue = -1, int oc = 0)
        {
            if (left == 0 || right == 0) return this;
            preConditionKey = key == 0 ? (int)Lib.ID.ID.id : key;
            _pipeline = _pipeline ?? new Pipeline();
            var c = _pipeline.Get(preConditionKey);
            c.upValueLayer = upvalue;
            c.otherCompare = oc;
            c.SetByKey<T>(left, right, compare);
            return this;
        }

        public Processer While<T>(string left, T right, Lib.P.CompareOp compare, int key = 0, int upvalue = -1, int oc = 0)
        {
            if (!string.IsNullOrEmpty(left))
            {
                preConditionKey = key == 0 ? (int)Lib.ID.ID.id : key;
                _pipeline = _pipeline ?? new Pipeline();
                var c = _pipeline.Get(preConditionKey);
                c.upValueLayer = upvalue;
                c.otherCompare = oc;
                c.Set<T>(left, right, compare);
            }
            return this;
        }       //aot ref called

        public Processer While<T>(uint left, T right, Lib.P.CompareOp compare, int key = 0, int upvalue = -1, int oc = 0)
        {
            if (left > 0)
            {
                preConditionKey = key == 0 ? (int)Lib.ID.ID.id : key;
                _pipeline = _pipeline ?? new Pipeline();
                var c = _pipeline.Get(preConditionKey);
                c.upValueLayer = upvalue;
                c.otherCompare = oc;
                c.Set<T>(left, right, compare);
            }
            return this;
        }         //aot ref called

        public Processer While(string left, object right, TypeCode code, bool isRef, Lib.P.CompareOp compare, int key = 0, int upvalue = -1, int oc = 0)
        {
            if (!string.IsNullOrEmpty(left))
            {
                preConditionKey = key == 0 ? (int)Lib.ID.ID.id : key;
                _pipeline = _pipeline ?? new Pipeline();
                var c = _pipeline.Get(preConditionKey);
                c.key = preConditionKey;
                c.upValueLayer = upvalue;
                c.otherCompare = oc;
                try
                {
                    if (!isRef)
                    {
                        switch (code)
                        {
                            case TypeCode.Boolean: c.Set<Boolean>(left, (Boolean)right, compare); break;
                            case TypeCode.Char: c.Set<Char>(left, (Char)right, compare); break;
                            case TypeCode.SByte: c.Set<SByte>(left, (SByte)right, compare); break;
                            case TypeCode.Byte: c.Set<Byte>(left, (Byte)right, compare); break;
                            case TypeCode.Int16: c.Set<Int16>(left, (Int16)right, compare); break;
                            case TypeCode.UInt16: c.Set<UInt16>(left, (UInt16)right, compare); break;
                            case TypeCode.Int32: c.Set<Int32>(left, (Int32)right, compare); break;
                            case TypeCode.UInt32: c.Set<UInt32>(left, (UInt32)right, compare); break;
                            case TypeCode.Int64: c.Set<Int64>(left, (Int64)right, compare); break;
                            case TypeCode.UInt64: c.Set<UInt64>(left, (UInt64)right, compare); break;
                            case TypeCode.Single: c.Set<Single>(left, (Single)right, compare); break;
                            case TypeCode.Double: c.Set<Double>(left, (Double)right, compare); break;
                            case TypeCode.Decimal: c.Set<Decimal>(left, (Decimal)right, compare); break;
                            case TypeCode.DateTime: c.Set<DateTime>(left, (DateTime)right, compare); break;
                            case TypeCode.String: c.Set<String>(left, (String)right, compare); break;
                            case TypeCode.Empty: c.Set<object>(left, right, compare); break;
                            default: _pipeline.Del(c.key); break;
                        }
                    }
                    else if (right != null)
                    {
                        var rk = right.ToString();
                        switch (code)
                        {
                            case TypeCode.Boolean: c.SetByKey<Boolean>(left, rk, compare); break;
                            case TypeCode.Char: c.SetByKey<Char>(left, rk, compare); break;
                            case TypeCode.SByte: c.SetByKey<SByte>(left, rk, compare); break;
                            case TypeCode.Byte: c.SetByKey<Byte>(left, rk, compare); break;
                            case TypeCode.Int16: c.SetByKey<Int16>(left, rk, compare); break;
                            case TypeCode.UInt16: c.SetByKey<UInt16>(left, rk, compare); break;
                            case TypeCode.Int32: c.SetByKey<Int32>(left, rk, compare); break;
                            case TypeCode.UInt32: c.SetByKey<UInt32>(left, rk, compare); break;
                            case TypeCode.Int64: c.SetByKey<Int64>(left, rk, compare); break;
                            case TypeCode.UInt64: c.SetByKey<UInt64>(left, rk, compare); break;
                            case TypeCode.Single: c.SetByKey<Single>(left, rk, compare); break;
                            case TypeCode.Double: c.SetByKey<Double>(left, rk, compare); break;
                            case TypeCode.Decimal: c.SetByKey<Decimal>(left, rk, compare); break;
                            case TypeCode.DateTime: c.SetByKey<DateTime>(left, rk, compare); break;
                            case TypeCode.String: c.SetByKey<String>(left, rk, compare); break;
                            case TypeCode.Empty: c.SetByKey<object>(left, rk, compare); break;
                            default: _pipeline.Del(c.key); break;
                        }
                    }
                    else
                    {
                        _pipeline.Del(c.key);
                    }
                }
                catch (Exception e)
                {
                    UnityEngine.Debug.LogException(e);
                    UnityEngine.Debug.LogError(string.Format("Left:{0},Right:{1},Type:{2}", left, right, code));
                }
            }
            return this;
        }       //aot ref called

        public Processer While(uint left, object right, TypeCode code, bool isRef, Lib.P.CompareOp compare, int key = 0, int upvalue = -1, int oc = 0)
        {
            if (left > 0)
            {
                preConditionKey = key == 0 ? (int)Lib.ID.ID.id : key;
                _pipeline = _pipeline ?? new Pipeline();
                var c = _pipeline.Get(preConditionKey);
                c.key = preConditionKey;
                c.upValueLayer = upvalue;
                c.otherCompare = oc;
                try
                {
                    if (!isRef)
                    {
                        switch (code)
                        {
                            case TypeCode.Boolean: c.Set<Boolean>(left, (Boolean)right, compare); break;
                            case TypeCode.Char: c.Set<Char>(left, (Char)right, compare); break;
                            case TypeCode.SByte: c.Set<SByte>(left, (SByte)right, compare); break;
                            case TypeCode.Byte: c.Set<Byte>(left, (Byte)right, compare); break;
                            case TypeCode.Int16: c.Set<Int16>(left, (Int16)right, compare); break;
                            case TypeCode.UInt16: c.Set<UInt16>(left, (UInt16)right, compare); break;
                            case TypeCode.Int32: c.Set<Int32>(left, (Int32)right, compare); break;
                            case TypeCode.UInt32: c.Set<UInt32>(left, (UInt32)right, compare); break;
                            case TypeCode.Int64: c.Set<Int64>(left, (Int64)right, compare); break;
                            case TypeCode.UInt64: c.Set<UInt64>(left, (UInt64)right, compare); break;
                            case TypeCode.Single: c.Set<Single>(left, (Single)right, compare); break;
                            case TypeCode.Double: c.Set<Double>(left, (Double)right, compare); break;
                            case TypeCode.Decimal: c.Set<Decimal>(left, (Decimal)right, compare); break;
                            case TypeCode.DateTime: c.Set<DateTime>(left, (DateTime)right, compare); break;
                            case TypeCode.String: c.Set<String>(left, (String)right, compare); break;
                            case TypeCode.Empty: c.Set<object>(left, right, compare); break;
                            default: _pipeline.Del(c.key); break;
                        }
                    }
                    else if (right != null)
                    {
                        var rk = (uint)right;
                        switch (code)
                        {
                            case TypeCode.Boolean: c.SetByKey<Boolean>(left, rk, compare); break;
                            case TypeCode.Char: c.SetByKey<Char>(left, rk, compare); break;
                            case TypeCode.SByte: c.SetByKey<SByte>(left, rk, compare); break;
                            case TypeCode.Byte: c.SetByKey<Byte>(left, rk, compare); break;
                            case TypeCode.Int16: c.SetByKey<Int16>(left, rk, compare); break;
                            case TypeCode.UInt16: c.SetByKey<UInt16>(left, rk, compare); break;
                            case TypeCode.Int32: c.SetByKey<Int32>(left, rk, compare); break;
                            case TypeCode.UInt32: c.SetByKey<UInt32>(left, rk, compare); break;
                            case TypeCode.Int64: c.SetByKey<Int64>(left, rk, compare); break;
                            case TypeCode.UInt64: c.SetByKey<UInt64>(left, rk, compare); break;
                            case TypeCode.Single: c.SetByKey<Single>(left, rk, compare); break;
                            case TypeCode.Double: c.SetByKey<Double>(left, rk, compare); break;
                            case TypeCode.Decimal: c.SetByKey<Decimal>(left, rk, compare); break;
                            case TypeCode.DateTime: c.SetByKey<DateTime>(left, rk, compare); break;
                            case TypeCode.String: c.SetByKey<String>(left, rk, compare); break;
                            case TypeCode.Empty: c.SetByKey<object>(left, rk, compare); break;
                            default: _pipeline.Del(c.key); break;
                        }
                    }
                    else
                    {
                        _pipeline.Del(c.key);
                    }
                }
                catch (Exception e)
                {
                    UnityEngine.Debug.LogException(e);
                }
            }
            return this;
        }         //aot ref called

        public Processer Arg<T>(T arg, int key = 0)
        {
            if (_pipeline != null && arg != null)
            {
                _pipeline.key = key;
                _pipeline.arg?.Release();
                _pipeline.arg = new Parameter<T>(0, arg);
            }
            return this;
        }

        public Processer Switch(int s, int d)
        {
            if (_pipeline != null)
                GetTransition(s, d).Add(_pipeline);
            _pipeline = null;
            preConditionKey = 0;
            return this;
        }

        #endregion
    }

    public class DataSet : Lib.P.Proxy, IDataSet
    {
        public void SetVal<T>(T val, [System.Runtime.CompilerServices.CallerMemberName] string key = null)
        {
            Set<T>(key.ToID(), val);
        }

        public T GetVal<T>([System.Runtime.CompilerServices.CallerMemberName] string key = null)
        {

            return Get<T>(key.ToID());
        }

        IDataSet IDataSet.Del(uint key)
        {
            Del(key);
            return this;
        }

        void IDataSet.Set<T>(uint key, T val)
        {
            Set(key, val);
        }

        void IDataSet.Set<T>(uint key, Func<uint, T> get, Action<uint, T> set)
        {
            Set(key, get, set);
        }

        void IDataSet.SetVal(uint key, object val)
        {
            SetVal(key, val);
        }

        void IDataSet.Clear()
        {
            Clear();
        }

        public IDataSet UpValue(bool state, IDataSet upvalue)
        {
            if (state)
            {
                if (upvalue != null)
                {
                    Set(Condition.C_UPVALUE_ID, upvalue);
                    return this;
                }
            }
            Del(Condition.C_UPVALUE_ID);
            return this;
        }
    }
}
namespace AI
{
    using Lib.Crc;

    public static partial class AotCLSExtends
    {

        static readonly private Dictionary<string, uint> _s2id = new Dictionary<string, uint>();
        static readonly private Dictionary<int, uint> _i2id = new Dictionary<int, uint>();

        public static uint ToID(this int i)
        {
            uint id;
            if (_i2id.TryGetValue(i, out id))
                return id;
            id = i.ToString().ToID();
            _i2id[i] = id;
            return id;
        }

        public static uint ToID(this string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                if (_s2id.ContainsKey(str)) return _s2id[str];
                var id = CRC32.CRC(str);
                _s2id[str] = id;
                return id;
            }
            return 0;
        }

    }
}
