namespace AI
{
    public class TArg<T> : IEventArgs
    {
        public int eventID { get; set; }

        public T arg { get; set; }

        public TArg()
        {
        }

        public TArg(int id, T arg)
        {
            this.eventID = id;
            this.arg = arg;
        }

        public void Reset()
        {
            eventID = 0;
            arg = default(T);
        }

        public override string ToString()
        {
            return string.Format("arg:{0}", arg);
        }

    }
}
