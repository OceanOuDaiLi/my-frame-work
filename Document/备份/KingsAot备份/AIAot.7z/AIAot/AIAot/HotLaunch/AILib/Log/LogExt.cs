using System;
using System.Diagnostics;

namespace AI
{
    public static class LogExt
    {
        static public event Action OnException;

        [Conditional("__LOG__")]
        static public void Log(this ILog log, string msg)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Log, msg);
        }

        [Conditional("__LOG__")]
        static public void Log(this ILog log, string format, params object[] args)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Log, format, args);
        }

        [Conditional("__LOG__")]
        static public void Debug(this ILog log, object msg)
        {
            if (msg != null) log.Log(msg.ToString());
        }

        [Conditional("__LOG__")]
        static public void Info(this ILog log, string msg)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Info, msg);
        }

        [Conditional("__LOG__")]
        static public void Info(this ILog log, string format, params object[] args)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Info, format, args);
        }

        [Conditional("__LOG__")]
        static public void Warn(this ILog log, string msg)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Warn, msg);
        }

        [Conditional("__LOG__")]
        static public void Warn(this ILog log, string format, params object[] args)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Warn, format, args);
        }

        [Conditional("__LOG__")]
        static public void ELog(this ILog log, string msg)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Error, msg);
        }

        [Conditional("__LOG__")]
        static public void Elog(this ILog log, string format, params object[] args)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Error, format, args);
        }

        [Conditional("__LOG__")]
        static public void Error(this ILog log, string msg)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Error, msg);
        }

        [Conditional("__LOG__")]
        static public void Error(this ILog log, string format, params object[] args)
        {
            log = log ?? ILog.loger;
            if (log != null) log.Print(LogType.Error, format, args);
        }

        static public void Exception(this ILog log, Exception exception)
        {
            log = log ?? ILog.loger;
            if (log != null && exception != null)
            {
                log.Error("<color=yellow> Exception!!! </color>{0}\n{1}", exception.Message, exception.StackTrace);
                OnException?.Invoke();
            }
        }
    }
}