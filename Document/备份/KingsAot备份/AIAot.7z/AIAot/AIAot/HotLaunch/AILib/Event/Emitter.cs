﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.ConstrainedExecution;

namespace AI
{
    public delegate void ECall(object sender, object accepter, IEventArgs args);

    public class Emitter : CriticalFinalizerObject, IEmitter
    {
        #region Private

        private readonly Dictionary<int, Listener> _listeners = new Dictionary<int, Listener>();
        private readonly Dictionary<Type, Dictionary<int, Listener>> _t2c = new Dictionary<Type, Dictionary<int, Listener>>();

        private string _name;
        private bool _enable = false;

        private ECall _anonymous;
        protected int _anonymousCode;

        #endregion

        protected readonly int code;
        public virtual int hashCode { get; private set; }

        public bool enableTrigger
        {
            get { return _enable; }
            set
            {
                if (_enable != value)
                {
                    _enable = value;
                    if (_emitter == this) return;
                    if (_enable)
                    {
                        _anonymous = _anonymous ?? new ECall(RecvAnonymousEvent);
                        EventCenter.On(_anonymousCode == 0 ? hashCode : _anonymousCode, _anonymous, this);
                    }
                    else EventCenter.Off(_anonymousCode == 0 ? hashCode : _anonymousCode, _anonymous, this);
                }
            }
        }

        public object sender { get; private set; }

        public Emitter(object sender)
        {
            this.sender = sender ?? this;
            _anonymousCode = code = hashCode = this.sender.GetHashCode();
            OnLister();
        }

        public Emitter() : this(null)
        {
        }

        public Emitter SetName(string name) { _name = name; return this; }

        public void On(int id, ECall call, object accepter = null)
        {
            if (call != null && id != 0)
            {
                Listener listener = null;
                _listeners.TryGetValue(id, out listener);
                Listener.Get(id, call, accepter, ref listener);
                _listeners[id] = listener;
            }
        }

        public void Once(int id, ECall call, object accepter = null)
        {
            if (call != null && id != 0)
            {
                Listener listener = null;
                _listeners.TryGetValue(id, out listener);
                Listener.Get(id, call, accepter, ref listener, true);
                _listeners[id] = listener;
            }
        }

        public void Capture(int id, ECall call, object accepter = null)
        {
            if (call != null && id != 0)
            {
                Listener listener = null;
                _listeners.TryGetValue(id, out listener);
                Listener.Get(id, call, accepter, ref listener, false, true);
                _listeners[id] = listener;
            }
        }

        public bool Contact(int id, object accepter, IEventArgs args)
        {
            if (!_enable) return false;

            Listener listener = null;
            if (_listeners.TryGetValue(id, out listener))
            {
                var s = listener.Contact(sender, accepter, args);
                return s;
            }
            return false;
        }

        public bool Contact(int id, object accepter, params object[] args)
        {
            if (!_enable) return false;

            var e = new ObjectArgs();
            e.eventID = id;
            e.args = args;
            return Contact(id, accepter, e);
        }

        public void Off(int id, ECall call, object accepter = null)
        {
            if (call != null || accepter != null)
            {
                Listener listener = null;
                if (_listeners.TryGetValue(id, out listener))
                {
                    Listener.Remove(listener, call, accepter);
                }
            }
        }

        public void Trigger(int id, params object[] args)
        {
            if (!_enable) return;

            var e = new ObjectArgs();
            e.eventID = id;
            e.args = args;
            Trigger(id, e);
        }

        public void Trigger(int id, IEventArgs args)
        {
            if (!_enable) return;
            Listener listener = null;
            args.eventID = id;
            if (_listeners.TryGetValue(id, out listener))
                listener.Trigger(sender, args);
            RecvAnonymousEvent(this, this, args);
        }

        public void Trigger(int id)
        {
            _nullEArgs.eventID = id;
            Trigger(id, _nullEArgs);
        }

        public void SimpleTrigger<T>(int id, T args)
        {
            if (!_enable) return;

            var e = new TArg<T>();
            e.eventID = id;
            e.arg = args;
            Trigger(id, e);
        }

        public void Clear()
        {
            if (_listeners.Count > 0)
            {
                var dictEnumerator = _listeners.GetEnumerator();
                while (dictEnumerator.MoveNext())
                {
                    dictEnumerator.Current.Value.Reset();
                }
            }
            _listeners.Clear();
        }

        public void Clear(Func<int, bool> condition)
        {
            if (condition != null)
            {
                var ls = new Dictionary<int, Listener>(_listeners);

                var dictEnumerator = ls.GetEnumerator();
                while (dictEnumerator.MoveNext())
                {
                    if (condition(dictEnumerator.Current.Key))
                    {
                        dictEnumerator.Current.Value.Reset();
                        _listeners.Remove(dictEnumerator.Current.Key);
                    }
                }
            }
        }

        public override string ToString()
        {
            return _name ?? base.ToString();
        }

        #region Anonymous

        private void RecvAnonymousEvent(object sender, object accepter, IEventArgs args)
        {
            if (args != null)
            {
                Dictionary<int, Listener> lis = null;
                var ty = args.GetType();
                if (_t2c.TryGetValue(args.GetType(), out lis) && lis != null)
                {
                    Listener listener = null;
                    if ((lis.TryGetValue(args.eventID, out listener) || lis.TryGetValue(0, out listener)) && listener != null)
                    {
                        listener.Trigger(sender, args);
                        return;
                    }
                }
                OnAnonymousEvent(sender, accepter, args);
            }
        }

        protected virtual void OnAnonymousEvent(object sender, object accepter, IEventArgs args)
        {

        }

        public void Receive<T>(ECall call, int id = 0, bool once = false) where T : class, IEventArgs
        {
            if (call != null)
            {
                var ty = typeof(T);
                Dictionary<int, Listener> list = null;
                if (!_t2c.TryGetValue(ty, out list) || list == null)
                {
                    list = new Dictionary<int, Listener>();
                    _t2c[ty] = list;
                }
                Listener listener = null;
                list.TryGetValue(id, out listener);
                Listener.Get(id, call, this, ref listener, once);
                list[id] = listener;
            }
        }

        public void UnReceive<T>(ECall call, int id = 0) where T : class, IEventArgs
        {
            if (call != null)
            {
                var ty = typeof(T);
                Dictionary<int, Listener> list = null;
                if (_t2c.TryGetValue(ty, out list))
                {
                    Listener listener;
                    if (list.TryGetValue(id, out listener))
                        Listener.Remove(listener, call, this);
                }
            }
        }

        public void UnRecvive<T>() where T : class, IEventArgs
        {
            var ty = typeof(T);
            Dictionary<int, Listener> list = null;
            if (_t2c.TryGetValue(ty, out list))
            {
                var dictEnumerator = list.GetEnumerator();
                while (dictEnumerator.MoveNext())
                {
                    dictEnumerator.Current.Value.Reset();
                }

                list.Clear();
                _t2c.Remove(ty);
            }
        }

        protected virtual void OnLister() { }

        protected virtual void OnUnLister()
        {

        }


        #endregion

        #region Static

        static public ILog Loger;

        private readonly static object[] _nullArgs = new object[0];
        private readonly static IEventArgs _nullEArgs = new TArg<int>(0, 0);
        private readonly static object _null = new object();
        static private IEmitter _emitter;

        static public IEmitter EventCenter
        {
            get
            {
                _emitter = _emitter ?? CreateCenter();
                return _emitter;
            }
        }

        static IEmitter CreateCenter()
        {
            if (_emitter == null)
            {
                var type = Type.GetType("Event.EventCenter", false, true);
                if (type != null && typeof(IEmitter).IsAssignableFrom(type))
                {
                    try
                    {
                        _emitter = Activator.CreateInstance(type) as IEmitter;
                        _emitter.enableTrigger = true;
                        return _emitter;
                    }
                    catch (Exception e)
                    {
                        LogExt.Exception(null, e);
                    }
                }
                return new Emitter() { _enable = true, _name = "__EVENT_CENTER__" };
            }
            return null;
        }


        #endregion

        #region Class

        class Listener
        {
            public int id;
            public ECall call;
            public object accpeter;
            public bool once = false;
            public bool isCapture = false;
            public IList<Listener> listeners = null;

            public void Trigger(object sender, IEventArgs args)
            {
                if (listeners != null && listeners.Count > 0)
                {
                    var i = 0;
                    var s = false;
                    for (i = listeners.Count - 1; i >= 0; i--)
                    {
                        if (listeners == null) break;
                        var l = listeners[i];
                        l.Trigger(sender, args);
                        if (l.once)
                        {
                            l.id = 0;
                            s = true;
                        }
                        if (l.isCapture) break;
                    }
                    if (s) Remove(this, null, _null);

                }
                else if (call != null)
                {
                    try
                    {
                        call(sender, accpeter, args);
                    }
                    catch (Exception e)
                    {
                        UnityEngine.Debug.LogException(e);
                    }
                }
            }

            public bool Contact(object sender, object accpeter, IEventArgs args)
            {
                if (listeners != null && listeners.Count > 0)
                {
                    var len = listeners.Count;
                    for (int i = 0; i < len; i++)
                    {
                        var l = listeners[i];
                        if (accpeter.Equals(l.accpeter))
                        {
                            l.Trigger(sender, args);
                            return true;
                        }
                    }
                }
                return false;
            }

            public void Reset()
            {
                id = 0;
                call = null;
                once = false;
                isCapture = false;
                if (listeners != null && listeners.Count > 0)
                {
                    var dictEnumerator = listeners.GetEnumerator();
                    while (dictEnumerator.MoveNext())
                    {
                        dictEnumerator.Current.Reset();
                    }

                    listeners.Clear();
                    listeners = null;
                }
            }

            static public Listener Get(
                int id,
                ECall call,
                object accpeter,
                ref Listener node,
                bool once = false,
                bool capture = false
            )
            {
                var l = new Listener(); ;
                node = node ?? new Listener();
                node.id = id;
                node.listeners = node.listeners ?? new List<Listener>();
                l.id = id;
                l.call = call;
                l.accpeter = accpeter;
                l.once = once;
                l.isCapture = capture;
                if (capture) node.listeners.Insert(0, l);
                else node.listeners.Add(l);
                return l;
            }

            static public void Remove(Listener node, ECall call, object accepter)
            {
                if (node != null && node.listeners.Count > 0 && (call != null || accepter != null))
                {
                    var len = node.listeners.Count;
                    for (int i = len - 1; i >= 0; i--)
                    {
                        var l = node.listeners[i];
                        if (l.id == 0)
                        {
                            node.listeners.RemoveAt(i);
                            l.Reset();
                        }
                        else if (accepter != _null)
                        {
                            if (((accepter == null || accepter.Equals(l.accpeter))
                                && (call == null || call.Equals(l.call))))
                            {
                                node.listeners.RemoveAt(i);
                                l.Reset();
                            }
                        }
                    }
                }
            }

        }

        #endregion

    }



    public static partial class AotCLSExtends
    {
        static public T GetValue<T>(this ObjectArgs args, int index, T v = default(T))
        {
            if (args != null && args.args != null)
            {
                if (args.args.Length > index) return args.args[index].To<T>(v);
            }
            return v;
        }

        [Conditional("__LOG__")]
        static public void F(this object obj, ref string result, string format, params object[] args)
        {
            if (ILog.enableLog)
            {
                if (String.IsNullOrEmpty(format))
                {
                    if (args != null && args.Length == 1)
                        result = args[0].ToString();
                    else
                        result = args?.ToString();
                    return;
                }
                result = string.Format(format, args);
                return;
            }
            result = null;
        }
    }

}
