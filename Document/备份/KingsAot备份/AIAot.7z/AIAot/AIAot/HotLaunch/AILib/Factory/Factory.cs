﻿using System;
using System.Collections.Generic;

public class Factory
{
    public delegate T TCreater<T>(int uniqid = 0);
    public delegate object TCreater(object type, int uniqid = 0);
    private delegate T TGet<T>(int uniqid, bool bind);

    static public TCreater FactoryCreater;

    static private readonly System.Reflection.MethodInfo _newMethod;
    static private Dictionary<Type, Delegate> _gets = new Dictionary<Type, Delegate>();
    static private Dictionary<object, Dictionary<int, object>> _binders = new Dictionary<object, Dictionary<int, object>>();

    static Factory()
    {
        _newMethod = typeof(Factory).GetMethod("New", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
    }

    static public object Get(object type, int uniqid = 0)
    {
        if (type != null)
        {
            Dictionary<int, object> dic = null;
            var ty = type as Type;
            if (_binders.TryGetValue(type, out dic) && dic.ContainsKey(uniqid)) return dic[uniqid];
        }
        return null;
    }

    static public T Get<T>(int uniqid = 0)
    {
        try
        {
            return (T)Get(typeof(T), uniqid);
        }
        catch (Exception e)
        {
            AI.LogExt.Error(AI.Emitter.Loger, e.ToString());
            return default(T);
        }
    }

    static public void Set(object type, object val, int uniqid = 0)
    {
        if (type != null)
        {
            Dictionary<int, object> dic = null;
            if (!_binders.TryGetValue(type, out dic))
            {
                dic = new Dictionary<int, object>();
                _binders[type] = dic;
            }
            dic[uniqid] = val;
        }
    }

    static public T Pop<T>(int uniqid = 0, bool bind = false) where T : class
    {
        var ty = typeof(T);
        Delegate get = null;
        if (!_gets.TryGetValue(ty, out get) || get == null)
        {
            get = new TGet<T>(Factory<T>.Bind);
            _gets[ty] = get;
        }
        return (get as TGet<T>)?.Invoke(uniqid, bind);
    }

    static public object Pop(object type, int uniqid = 0, bool bind = false)
    {
        if (type != null)
        {
            var ty = type as Type;
            if (ty == null)
            {
                var ret = Get(type, uniqid);
                if (ret == null)
                {
                    ret = Create(type, uniqid);
                    if (bind) Set(type, ret, uniqid);
                }
                return ret;
            }
            else
            {

                Delegate get = null;
                if (_gets.TryGetValue(ty, out get) && get != null) return get.DynamicInvoke(uniqid, bind);

                var fty = typeof(Factory<>).MakeGenericType(ty);
                if (fty != null)
                {
                    var method = fty.GetMethod("Bind", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public);
                    if (method != null)
                    {
                        var gty = typeof(TGet<>).MakeGenericType(ty);
                        var call = Delegate.CreateDelegate(gty, method);
                        if (call != null) _gets[ty] = call;
                        return call.DynamicInvoke(uniqid, bind);
                    }
                }
            }
        }
        return null;
    }

    static protected object Create(object type, int uniqid = 0)
    {
        var ty = type as Type;
        return FactoryCreater?.Invoke(type, uniqid) ?? (ty != null && ty.IsClass ? Activator.CreateInstance(ty) : null);
    }

    static protected T Create<T>(int uniqid = 0)
    {
        try
        {
            return (T)Create(typeof(T), uniqid);
        }
        catch (Exception e)
        {
            AI.LogExt.Error(AI.Emitter.Loger, e.ToString());
            return default(T);
        }
    }

    static private T New<T>(int uniqid = 0) where T : class, new()
    {
        return new T();
    }

    static protected TCreater<T> MakeNew<T>() where T : class
    {
        if (typeof(T).IsClass)
        {
            var m = _newMethod.MakeGenericMethod(typeof(T));
            return Delegate.CreateDelegate(typeof(TCreater<T>), m) as TCreater<T>;
        }
        return null;
    }
}

public class Factory<T> : Factory where T : class
{
    static readonly private Type __TYPE__;
    static public TCreater<T> Creater;

    static Factory()
    {
        __TYPE__ = typeof(T);
        var m = __TYPE__.GetMethod("__INIT__", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.FlattenHierarchy);
        if (m != null) m.Invoke(null, null);
    }

    static public T Create()
    {
        return Bind(0, false);
    }

    static public T New()
    {
        return Bind(-1, false);
    }

    static public T Uniqid(int uniqid)
    {
        return Bind(uniqid, false);
    }

    static public T Bind(int uniqid, bool bind)
    {
        T val = default(T);
        if (uniqid != -1)
        {
            val = Get<T>(uniqid);
            if (val != null) return val;
        }
        else bind = false;
        val = Creater?.Invoke(uniqid) ?? Create<T>(uniqid);
        if (bind) Set(__TYPE__, val, uniqid);
        return val;
    }

}
