﻿namespace AI.Object
{
    public enum AnimationEnum
    {
        Stand = 0,                                      //无球站立
        AtkAssisStand = 1,                              //无球进攻站立		
        AtkDrribleStand = 2,                            //持球进攻站立		
        AtkAssisMove = 3,                               //无球进攻移动		
        AtkDrribleMove = 4,                             //持球进攻移动		
        Stand_Hold_Ball_2 = 5,                          //持球二运站立		
        DefStand = 6,                                   //防守站立		
        DefMove = 7,                                    //防守移动		
        Link = 8,                                       //衔接状态		 
        AskBall = 9,                                    //要球			
        Stiff = 10,                                     //硬直			

        Shoot = 11,                                     //投篮			
        FreeThrow = 12,                                 //罚球			
        Layup = 13,                                     //上篮		
        Dunk = 14,                                      //扣篮			
        Hook = 15,                                      //勾手			
        Steal = 16,                                     //抢断			
        Pass = 17,                                      //传球			
        Rebound = 18,                                   //篮板			
        Block = 19,                                     //盖帽			
        Break = 20,                                     //突破			
        Postup = 21,                                    //背身			
        Split = 22,                                     //分球			
        Intercept = 23,                                 //拦截			
        DoublePump = 24,                                //拉杆			
        CatchBall = 25,                                 //接球			
        PickRoll = 26,                                  //挡拆			
        BoxOut = 27,                                    //卡位
        Jump = 28,                                      //跳球
        AlleyOop = 29,                                  //空接

    }
}
