using System;

namespace AI
{
    public interface IEmitter
    {
        int hashCode { get; }
        object sender { get; }
        bool enableTrigger { get; set; }

        /// <summary>
        /// ����
        /// </summary>
        /// <param name="id"></param>
        /// <param name="call"></param>
        /// <param name="accepter"></param>
        void On(int id, ECall call, object accepter = null);


        /// <summary>
        /// ����һ��
        /// </summary>
        /// <param name="id"></param>
        /// <param name="call"></param>
        /// <param name="accepter"></param>
        void Once(int id, ECall call, object accepter = null);


        /// <summary>
        /// ����
        /// </summary>
        /// <param name="id"></param>
        /// <param name="call"></param>
        /// <param name="accepter"></param>
        void Capture(int id, ECall call, object accepter = null);


        /// <summary>
        /// �Ƴ�����
        /// </summary>
        /// <param name="id"></param>
        /// <param name="call"></param>
        /// <param name="accepter"></param>
        void Off(int id, ECall call, object accepter = null);


        /// <summary>
        /// ����
        /// </summary>
        /// <param name="id"></param>
        /// <param name="args"></param>
        void Trigger(int id, params object[] args);
        void Trigger(int id, IEventArgs args);
        void Trigger(int id);
        void SimpleTrigger<T>(int id, T args);


        /// <summary>
        /// ��������
        /// </summary>
        /// <param name="id"></param>
        /// <param name="accepter"></param>
        /// <param name="args"></param>
        /// <returns>���߳ɹ����</returns>
        bool Contact(int id, object accepter, params object[] args);
        bool Contact(int id, object accepter, IEventArgs args);


        void Clear();
        void Clear(Func<int, bool> condition);
    }
}
