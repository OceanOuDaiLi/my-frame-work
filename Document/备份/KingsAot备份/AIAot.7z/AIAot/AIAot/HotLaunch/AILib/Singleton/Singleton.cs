﻿namespace AI
{
    using System;
    using System.Collections.Generic;

    public class Singleton
    {
        static protected event System.Action _releases;
        static readonly private Dictionary<Type, object> _insts = new Dictionary<Type, object>();
        static readonly private Dictionary<Type, System.Action> _releaseCalls = new Dictionary<Type, System.Action>();


        static public bool IsSinleton(object inst)
        {
            return _insts.ContainsValue(inst);
        }

        static public void Binding<T>(T inst, System.Action call)
        {
            Binding(typeof(T), inst, call);
        }

        static public void Binding(object inst, System.Action call)
        {
            if (inst == null) return;
            Binding(inst.GetType(), inst, call);
        }

        static public void Binding(Type type, object inst, System.Action call)
        {
            if (type != null)
            {
                if (inst == null || type.IsAssignableFrom(inst.GetType()))
                {
                    _insts[type] = inst;
                    if (inst == null)
                    {
                        if (_releaseCalls.TryGetValue(type, out call))
                        {
                            _releases -= call;
                            _releaseCalls.Remove(type);
                            call?.Invoke();
                        }
                    }
                    else if (call != null)
                    {
                        _releaseCalls[type] = call;
                        _releases -= call;
                        _releases += call;
                    }
                }
            }
        }

        static public T Get<T>() where T : class
        {
            return Singleton<T>.Inst;
        }

        static public object Get(Type type)
        {
            if (type != null && _insts.ContainsKey(type))
                return _insts[type];
            return null;
        }

        static public void ReleaseAll()
        {
            _releases?.Invoke();
            _insts.Clear();
        }
    }

    public class Singleton<T> : Singleton where T : class
    {
        static private readonly object _lock = new object();
        static private T _inst;
        static private bool _isCreated = false;

        public static bool IsCreated()
        {
            return _isCreated;
        }

        static public T Inst
        {
            get
            {
                if (_inst == null || MonoCheckNull())
                {
                    if (!_isCreated)
                    {
                        lock (_lock)
                        {
                            if (_inst == null)
                            {
                                _isCreated = true;
                                try
                                {
                                    _inst = Factory<T>.Create();
                                    if (_inst == null) LogExt.Error(null, " 单例[{0}]实例化异常", typeof(T));
                                    Binding(_inst, Release);
                                }
                                catch (Exception e)
                                {
                                    LogExt.Exception(null, e);
                                }
                            }
                        }
                    }
                    else
                    {
                        LogExt.Error(null, " 单例{0}的实例为空 ", typeof(T));
                    }
                }
                return _inst;
            }
        }

        static public void Release()
        {
            _releases -= Release;
            try
            {
                if ((_inst != null) && _inst is IRelease) (_inst as IRelease).Release();
            }
            catch (Exception e)
            {
                UnityEngine.Debug.LogException(e);
            }
            _inst = null;
            _isCreated = false;
            Binding<T>(null, null);
        }


        static bool MonoCheckNull()
        {
            if (Zeus.Launch.HotLaunch.Instance.DEBUG_MODEL)
            {
                if (_inst == null || ((_inst is UnityEngine.MonoBehaviour) && !(_inst as UnityEngine.MonoBehaviour)))
                    return true;
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

    }
}
