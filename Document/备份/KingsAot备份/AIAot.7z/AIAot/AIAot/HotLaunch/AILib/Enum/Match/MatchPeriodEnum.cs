﻿namespace AI
{
    public enum MatchPeriodEnum
    {
        None = 0,
        One = 1,
        Two,
        Three,
        Four,
        OT1,
        OT2,
        OT3,
        OT4,
    }
}