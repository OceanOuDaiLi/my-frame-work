﻿namespace AI
{
    /// <summary>
    /// 比赛对象接口
    /// </summary>
    public interface IMObject : IEntity, IFixedUpdate, ISystem
    {
        /// <summary>
        /// 焦点队伍
        /// </summary>
        TeamEnum team { get; }
        /// <summary>
        /// 焦点位置
        /// </summary>
        PosEnum pos { get; }
        /// <summary>
        /// 所属比赛
        /// </summary>
        object _match { get; }

        object _rts { get; }

        T rts<T>();

        T match<T>();

        int flag { get; }

        bool isFree { get; set; }

        int handDir { get; set; }

        IMObject Set(TeamEnum team, PosEnum pos);
        IMObject Set(object match);

        float[] exts { get; }

        bool IsInited();

        void SetFlag(int flag, bool cancel = false);

        bool CheckFlag(int flag);

        int GetGUID();

        /// <summary>
        /// 准备设置对应key的参数组
        /// </summary>
        /// <param name="key"></param>
        /// <param name="force">是否强制设置</param>
        /// <param name="token">校验token</param>
        /// <param name="length">参数数组长度</param>
        /// <returns></returns>
        IMObject ReadyArgs(int key, bool force = false, int token = 0, int length = 8);

        /// <summary>
        /// 设置参数值
        /// </summary>
        /// <param name="arg"></param>
        /// <param name="val"></param>
        /// <param name="end">结束参数数组设置</param>
        /// <returns></returns>
        IMObject SetArgs(int arg, int val, bool end = false);

        /// <summary>
        /// 获取设定的参数数组
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        int[] GetArgs(int key, bool endSet = false);

        void VerifyMessages(System.Text.StringBuilder builder);

    }
}