﻿using System;

namespace AI.Object
{
    [Flags]
    public enum PlayerStateEnum
    {
        None = 0,
        Stand = 1,                                          //无球站立
        Stand_No_Ball = 1 << 1,                             //无球进攻站立		
        Stand_Hold_Ball = 1 << 2,                           //持球进攻站立		
        Move_No_Ball = 1 << 3,                              //无球进攻移动		
        Move_Dribble_Ball = 1 << 4,                         //持球进攻移动		
        Stand_Hold_Ball_End_Dribble = 1 << 5,               //持球二运站立		
        Stand_Defend = 1 << 6,                              //防守站立		
        Move_Defend = 1 << 7,                               //防守移动		
        Link = 1 << 8,                                      //衔接状态		 
        AskBall = 1 << 9,                                   //要球			
        Stiff = 1 << 10,                                    //硬直			

        //--------------------------技能状态
        Shoot = 1 << 11,                                    //投篮			
        Foul = 1 << 12,                                     //罚球			
        Layup = 1 << 13,                                    //上篮		
        Dunk = 1 << 14,                                     //扣篮			
        Hook = 1 << 15,                                     //勾手			
        Break = 1 << 16,                                    //抢断			
        Pass = 1 << 17,                                     //传球			
        Rebound = 1 << 18,                                  //篮板			
        Block = 1 << 19,                                    //盖帽			
        Through = 1 << 20,                                  //突破			
        Back = 1 << 21,                                     //背身			
        Split = 1 << 22,                                    //分球			
        Intercept = 1 << 23,                                //拦截			
        DoublePump = 1 << 24,                               //拉杆			
        Catch = 1 << 25,                                    //接球			
        PickRoll = 1 << 26,                                 //挡拆			
        Lock = 1 << 27,                                     //卡位
        Jump = 1 << 28,                                     //跳球
        AlleyOop = 1 << 29,                                 //空接		 

        Common = 1 << 30,                                   //一般通用技能类型


        //--------------------------背身
        __BackHold = Back | Stand_Hold_Ball,                                    //背身持球
        __BackDribble = Back | Stand_Hold_Ball_End_Dribble,                     //背身运球
        __BackDribbleMove = Back | Move_Dribble_Ball,                           //背身运球移动


        //--------------------------自动切换
        m2s = -(Move_No_Ball | Stand),
        d2s = (Move_Dribble_Ball | Stand_Hold_Ball_End_Dribble),
        nm2s = -(Move_Defend | Stand),
        [FSM.Auto.Condition(leftID = (int)__BackDribbleMove, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        [FSM.Auto.Condition(MatchKey.slefIsholdPlayer, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)]
        [FSM.Auto.Condition(MatchKey.playerHandDir, MatchKey.playerAttackArea, true, TypeCode.Int32, Lib.P.CompareOp.Eq)]
        [FSM.Auto.Transition((int)__BackDribbleMove, (int)__BackDribble)]
        t0 = -1,
        [FSM.Auto.Condition(leftID = (int)__BackDribbleMove, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        [FSM.Auto.Condition(MatchKey.slefIsholdPlayer, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq)]
        [FSM.Auto.Condition(MatchKey.playerHandDir, MatchKey.playerAttackArea, true, TypeCode.Int32, Lib.P.CompareOp.NotEq)]
        [FSM.Auto.Transition((int)__BackDribbleMove, (int)(Back | Link))]
        t1 = -1,
        [FSM.Auto.Transition((int)(Back | Link), (int)Back)]
        t2 = -1,
        [FSM.Auto.Condition(leftID = (int)__BackDribbleMove, right = true, type = TypeCode.Boolean, compare = Lib.P.CompareOp.Eq)]
        [FSM.Auto.Condition(MatchKey.slefIsholdPlayer, true, false, TypeCode.Boolean, Lib.P.CompareOp.NotEq)]
        [FSM.Auto.Condition(MatchKey.playerHandDir, MatchKey.playerAttackArea, true, TypeCode.Int32, Lib.P.CompareOp.Eq)]
        [FSM.Auto.Transition((int)__BackDribbleMove, (int)Stand_No_Ball)]
        t3 = -1,

        __SkillStart = 11,
        __Stand = Stand_Defend | Stand_Hold_Ball | Stand_Hold_Ball_End_Dribble | Stand_No_Ball | Stand,
        __Goal = Shoot | Layup | Dunk | Hook | Foul | DoublePump,
        __Move = Move_Defend | Move_Dribble_Ball | Move_No_Ball,

        /// <summary>
        /// 飞行方式投篮
        /// </summary>
        __SGoal = Shoot | Foul | Layup | Hook | DoublePump,
        __Pass = Pass | Split,
        __Catch = Catch | Rebound | AlleyOop,
        __Interact = Break | Back | Through | Block | Intercept | Lock | PickRoll,
        __Hold = Through | Back,
        __NeedBall = __Goal | __Pass | Move_Dribble_Ball | Stand_Hold_Ball | Stand_Hold_Ball_End_Dribble,

        /// <summary>
        /// 得分技能
        /// </summary>
        __Score = Shoot | Foul | Layup | Hook | DoublePump | Dunk,

        /// <summary>
        /// 技能结束丢球
        /// </summary>
        __EndThrowBall = Break | Block | Intercept,

        /// <summary>
        /// 抛球类型技能
        /// </summary>
        __Throw = Shoot | Layup | Hook | Pass,

        /// <summary>
        /// 结束抛球类型技能
        /// </summary>
        __OverThrow = Rebound | Block | AlleyOop | Break | Intercept,

        /// <summary>
        /// 可无目标释放
        /// </summary>
        __NoTargetUse = Through | Back,

        /// <summary>
        /// 技能状态
        /// </summary>
        __Skill = Common | Shoot | Foul | Layup | Hook | Dunk | Break | Pass | Rebound | Block | Through | Back | Split | Intercept | DoublePump | Catch | PickRoll | AlleyOop | Lock | Jump,

        /// <summary>
        /// 硬直
        /// </summary>
        __Break = Break + 1,
        __Back = Back + 1,
        __Block = Block + 1,
        __Through = Through + 1,
        __Intercept = Intercept + 1,
        __Lock = Lock + 1,
        __PickRoll = PickRoll + 1,
        __Dunk = Dunk + 1,

        __Stiff = __Break | __Back | __Block | __Through | __Intercept | __Lock | __PickRoll | __Dunk,
    }
}
