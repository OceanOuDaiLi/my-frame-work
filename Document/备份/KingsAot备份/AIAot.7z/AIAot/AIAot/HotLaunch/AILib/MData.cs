﻿namespace AI
{
    public partial class MData : FSM.Auto.DataSet, IEntity
    {
        public ISystem container { get; set; }

        public void Release()
        {
            container = null;
            Clear();
        }
    }
}