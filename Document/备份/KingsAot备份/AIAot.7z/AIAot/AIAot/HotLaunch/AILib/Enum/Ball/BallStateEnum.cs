﻿using System;
using AI.FSM.Auto;

namespace AI.Object
{
    [Flags]
    public enum BallStateEnum
    {
        /// <summary>
        /// 自由球
        /// </summary>
        //[Condition(MatchKey.owner, 0, false, TypeCode.Int32, Lib.P.CompareOp.Eq , layer = 1)]
        /*[Condition(MatchKey.matchState, (int)MatchStateEnum.Rivalry, false, TypeCode.Int32, Lib.P.CompareOp.NotEq)]
        [Condition(MatchKey.matchState, (int)MatchStateEnum.Foul, false, TypeCode.Int32, Lib.P.CompareOp.NotEq)]
        [Condition(MatchKey.matchState, (int)MatchStateEnum.Pause, false, TypeCode.Int32, Lib.P.CompareOp.NotEq)]
        [Condition(MatchKey.matchState, (int)MatchStateEnum.Rebound, false, TypeCode.Int32, Lib.P.CompareOp.NotEq)]*/
        Free = 1 << 0,
        /// <summary>
        /// 持球
        /// </summary>
        //[Condition(MatchKey.owner, (int)PlayerStateEnum.Stand_Hold_Ball, false, TypeCode.Int32, Lib.P.CompareOp.Eq, layer = 1)]
        Hold = 1 << 1,
        /// <summary>
        /// 运球
        /// </summary>
        [Condition(MatchKey.ownerState, (int)PlayerStateEnum.Move_Dribble_Ball, false, TypeCode.Int32, Lib.P.CompareOp.Eq, layer = 1)]
        Dribble = 1 << 2,
        /// <summary>
        /// 运球结束，持球
        /// </summary>
        [Condition(MatchKey.ownerState, (int)PlayerStateEnum.Stand_Hold_Ball_End_Dribble, false, TypeCode.Int32, Lib.P.CompareOp.Eq, layer = 1)]
        DHold = 1 << 3,
        /// <summary>
        /// 投篮飞行
        /// </summary>
        ShootFly = 1 << 4,
        /// <summary>
        /// 投篮飞行可封盖
        /// </summary>
        [Condition(MatchKey.ownerState, (int)PlayerStateEnum.__Goal, false, TypeCode.Int32, Lib.P.CompareOp.Eq, layer = 1, otherCompare = 1)]
        [Condition(MatchKey.ballFly, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballReachTop, false, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        ShootFly_Block = 1 << 5,
        /// <summary>
        /// 篮板飞行
        /// </summary>
        [Condition(MatchKey.owner, (int)PosEnum.Rim, false, TypeCode.Int32, Lib.P.CompareOp.LEq, layer = 1)]
        [Condition(MatchKey.ballFly, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballCanBeCatch, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballHitFloor, false, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballReachTop, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(left = MachineConst.C_STATE_KEY_STR, right = (int)FoulIdle, type = TypeCode.Int32, compare = Lib.P.CompareOp.NotEq)]
        ReboundFly = 1 << 6,
        /// <summary>
        /// 不可抢篮板
        /// </summary>
        [Condition(MatchKey.owner, (int)PosEnum.Rim, false, TypeCode.Int32, Lib.P.CompareOp.LEq, layer = 1)]
        [Condition(MatchKey.ballFly, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballHitFloor, false, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballReachTop, false, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballCanBeCatch, false, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(left = MachineConst.C_STATE_KEY_STR, right = (int)FoulIdle, type = TypeCode.Int32, compare = Lib.P.CompareOp.NotEq)]
        ReboundFly_Not = 1 << 7,
        /// <summary>
        /// 篮板判定
        /// </summary>
        Rebound_Judge = 1 << 8,
        /// <summary>
        /// 传球飞行
        /// </summary>
        [Condition(MatchKey.ownerState, (int)PlayerStateEnum.Pass, false, TypeCode.Int32, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballFly, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        PassFly = 1 << 9,
        /// <summary>
        /// 击地传球
        /// </summary>
        PassFly_Hit = 1 << 10,
        /// <summary>
        /// 抛物线传球
        /// </summary>
        PassFly_Curve = 1 << 11,
        /// <summary>
        /// 地板球
        /// </summary>
        [Condition(left = MachineConst.C_STATE_KEY_STR, right = (int)Free, type = TypeCode.Int32, compare = Lib.P.CompareOp.NotEq)]
        [Condition(left = MachineConst.C_STATE_KEY_STR, right = (int)FoulIdle, type = TypeCode.Int32, compare = Lib.P.CompareOp.NotEq)]
        [Condition(MatchKey.ownerState, (int)PlayerStateEnum.Foul, false, TypeCode.Int32, Lib.P.CompareOp.NotEq, layer = 1)]
        [Condition(MatchKey.ballHitFloor, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.owner, 0, false, TypeCode.Int32, Lib.P.CompareOp.LEq, layer = 1)]
        Floor = 1 << 12,

        /// <summary>
        /// 罚球等待
        /// </summary>
        FoulIdle = 1 << 13,

        [Condition(left = MachineConst.C_STATE_KEY_STR, right = (int)__Hold, type = TypeCode.Int32, compare = Lib.P.CompareOp.NotEq, otherCompare = 1)]
        [Condition(MatchKey.ballFly, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        Fly = 1 << 14,

        ShootFlyFloor = 1 << 15,

        #region 转换

        [Condition(MatchKey.ballFly, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballReachTop, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        s2b = -(ShootFly_Block | ShootFly),

        /*[Condition(MatchKey.ballFly, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballReachTop, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballCanBeCatch, false, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        r2nr = ReboundFly | ReboundFly_Not,*/

        [Condition(MatchKey.ballFly, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballReachTop, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        [Condition(MatchKey.ballCanBeCatch, true, false, TypeCode.Boolean, Lib.P.CompareOp.Eq, layer = 1)]
        nt2r = -(ReboundFly_Not | ReboundFly),

        [Condition(MatchKey.goal, 0, false, TypeCode.Int32, Lib.P.CompareOp.Greater, layer = 1)]
        s2f = ShootFly | ShootFlyFloor,

        #endregion

        #region Other

        __Pass = PassFly | PassFly_Curve | PassFly_Hit,
        __Shoot = ShootFly | ShootFly_Block | ShootFlyFloor,
        __Rebound = ReboundFly | ReboundFly_Not | Rebound_Judge,

        /// <summary>
        /// 持球
        /// </summary>
        __Hold = Hold | DHold | Dribble,
        /// <summary>
        /// 飞行
        /// </summary>
        __Fly = __Pass | __Shoot | __Rebound | Fly,
        /// <summary>
        /// 空闲
        /// </summary>
        __Idle = Floor | FoulIdle | Free
        #endregion

    }
}