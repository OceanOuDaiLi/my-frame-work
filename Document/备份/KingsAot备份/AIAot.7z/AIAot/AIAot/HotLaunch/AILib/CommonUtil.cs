﻿
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;
using System.IO;
using System.Security.Cryptography;
using System.ComponentModel;

public static partial class CommonUtil
{
    #region Extend

    static public bool IsNull(this IList list)
    {
        bool b = true;
        if (list != null && list.Count > 0) return false;
        return b;
    }

    static public T[] ParseEnumValue<T>(this T e, IList list = null)
    {
        List<T> ts = null;
        Type t = typeof(T);
        if (typeof(T).IsEnum)
        {
            ts = new List<T>();
            if (t.GetCustomAttributes(typeof(FlagsAttribute), true).Length > 0)
            {
                ts = new List<T>();
                string[] ss = e.ToString().Split(',');
                if (ss.Length > 1)
                {
                    foreach (var v in ss)
                    {
                        T vv = (T)Enum.Parse(t, v);
                        ts.Add(vv);
                        if (list != null) list.Add(vv);
                    }
                }
                else
                {
                    ts.Add(e);
                    if (list != null) list.Add(e);
                }
            }
            else
            {
                ts.Add(e);
                if (list != null) list.Add(e);
            }
        }
        return ts == null ? null : ts.ToArray();
    }

    static public T To<T>(this object obj, T defv = default(T))
    {
        if (obj != null)
        {
            try
            {
                Type st = typeof(T);
                Type tt = obj.GetType();
                if (st == typeof(string)) obj = obj.ToString();
                else if (st == typeof(object)) return (T)obj;
                if (st.IsAssignableFrom(tt))
                {
                    return (T)obj;
                }
                else if (st == typeof(bool))
                {
                    bool b = false;
                    bool.TryParse(obj.ToString(), out b);
                    obj = b;
                    return (T)obj;
                }
                else if (tt.IsEnum && (st == typeof(int) || st == typeof(uint)))
                {
                    return (T)obj;
                }
                else if (st.IsEnum && (tt == typeof(int) || tt == typeof(uint)))
                {
                    return (T)obj;
                }
                else if ((st.IsPrimitive && (tt.IsPrimitive || tt == typeof(string) || tt == typeof(char))))
                {
                    return (T)Convert.ChangeType(obj, st);
                }
            }
            catch (Exception e)
            {
            }
        }
        return defv;
    }

    static public T Random<T>(this IList<T> list, Func<int, int, int> rnd = null)
    {
        if (list != null && list.Count > 0)
        {
            if (list.Count == 1) return list[0];
            var l = list.Count;
            l = rnd == null ? UnityEngine.Random.Range(0, l) : rnd(0, l - 1);
            return list[l];
        }
        return default(T);
    }

    static public T[] Random<T>(this IList<T> list, int count, Func<int, int, int> rnd = null)
    {
        if (list != null && list.Count > 0)
        {
            var ls = new List<T>(list);
            count = ls.Count > count ? count : ls.Count;
            if (count == ls.Count) return ls.ToArray();
            var v = new T[count];
            for (int i = 0; i < count; i++)
            {
                var idx = rnd == null ? UnityEngine.Random.Range(0, ls.Count) : rnd(0, ls.Count - 1);
                v[i] = ls[idx];
                ls.RemoveAt(idx);
            }
            return v;
        }

        return Array.Empty<T>();
    }

    static public int Flags(this int[] vals, bool move = false)
    {
        if (vals != null && vals.Length > 0)
        {
            var v = move ? 1 << vals[0] : vals[0];
            for (int i = 1; i < vals.Length; i++)
            {
                v |= move ? 1 << vals[i] : vals[i];
            }
            return v;
        }
        return -1;
    }

    #region File

    static public void CreateDir(string path)
    {
        if (!string.IsNullOrEmpty(path))
        {
            DirectoryInfo info = new DirectoryInfo(path);
            if (!info.Exists) info.Create();
        }
    }

    static public bool Exists(string path, out bool isDir)
    {
        bool b = false;
        isDir = true;
        if (!string.IsNullOrEmpty(path))
        {
            b = Directory.Exists(path);
            if (!b)
            {
                isDir = false;
                b = File.Exists(path);
            }
        }
        return b;
    }

    static public List<string> GetDirFiles(string dir, string pattern = "*", bool deeps = false)
    {
        List<string> files = new List<string>();
        bool ex = false, isDir = false;
        ex = Exists(dir, out isDir);
        if (ex && isDir)
        {
            string[] ps = string.IsNullOrEmpty(pattern) ? new string[] { "*" } : pattern.Split('|');
            for (int i = 0; i < ps.Length; i++)
            {
                files.AddRange(Directory.GetFiles(dir, ps[i], deeps ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly));
            }
        }
        return files;
    }

    static public void ClearFiles(string dir, string pattern = null, bool deeps = false, string onlydeletepix = null)
    {
        var isDir = false;
        if (Exists(dir, out isDir) && isDir)
        {
            string[] ps = string.IsNullOrEmpty(pattern) ? null : pattern.Split('|');
            var fs = GetDirFiles(dir, "*", true);
            if (fs.Count > 0)
            {
                foreach (var v in fs)
                {
                    var e = Path.GetExtension(v);
                    var n = Path.GetFileNameWithoutExtension(v);
                    if ((ps == null || !ps.Contains(e)) || (onlydeletepix != null && n.StartsWith(onlydeletepix)))
                        DeleteFile(v);
                }
            }
        }
    }

    static public void ClearFiles(string dir, IList<string> deletefiles, string ext = null)
    {
        if (string.IsNullOrEmpty(dir) || deletefiles == null || deletefiles.Count == 0) return;
        foreach (var v in deletefiles)
        {
            var f = Path.Combine(dir, v) + ext;
            DeleteFile(f);
        }

    }

    static public bool DeleteFile(string path, bool check = true)
    {
        bool b = true;
        if (check)
        {
            if (!string.IsNullOrEmpty(path))
            {
                bool ex = false, isFile = true;
                ex = Exists(path, out isFile);
                b = ex && !isFile;
            }
        }
        if (b) File.Delete(path);
        return b;
    }

    static public void CopyFiles(string spath, string dpath, string pattern = "*", bool deep = false, bool keepdir = false)
    {
        var fs = GetDirFiles(spath, pattern, deep);
        if (fs != null && fs.Count > 0)
            CopyFiles(fs, dpath, keepdir ? spath : null);
    }

    static public void CopyFiles(List<string> files, string dir, string olddir = null)
    {
        if (string.IsNullOrEmpty(dir) || files == null || files.Count == 0) return;
        CreateDir(dir);
        bool s = !string.IsNullOrEmpty(olddir);
        foreach (var v in files)
        {
            var n = s ? v.Replace(olddir, dir) : Path.Combine(dir, Path.GetFileName(v));
            if (s) CreateDir(Path.GetDirectoryName(n));
            File.Copy(v, n, true);
        }
    }

    static public List<string> GetMatchPath(string dir, string matchString)
    {
        bool isDir = false;
        if (Exists(dir, out isDir) && isDir)
        {
            string[] fl = Directory.GetFiles(dir, matchString);
            if (!fl.IsNull())
            {
                return fl.ToList();
            }
        }
        return null;
    }

    static public byte[] ReadFile(string path)
    {
        if (!string.IsNullOrEmpty(path))
        {
            FileStream fileStream = new FileStream(path, FileMode.Open);
            byte[] bs = new byte[fileStream.Length];
            fileStream.Read(bs, 0, bs.Length);
            fileStream.Flush();
            fileStream.Close();
            fileStream.Dispose();
            return bs;
        }
        return null;
    }

    static public long GetFileLen(string path)
    {
        if (File.Exists(path))
        {
            using (var f = File.OpenRead(path))
            {
                if (f != null)
                {
                    var len = f.Length;
                    f.Flush();
                    f.Close();
                    return len;
                }
            }
        }
        return 0;
    }

    static public void WriteFile(string path, byte[] buffer, FileMode mode = FileMode.Append)
    {
        if (!string.IsNullOrEmpty(path))
        {
            try
            {
                FileStream fileStream = new FileStream(path, mode);
                fileStream.Write(buffer, 0, buffer.Length);
                fileStream.Flush();
                fileStream.Close();
                fileStream.Dispose();
            }
            catch
            {

            }
        }
    }

    static public string FormatPath(string path)
    {
        if (!string.IsNullOrEmpty(path))
            path = path.Replace(@"\\", "/").Replace(@"\", "/");
        return path;
    }

    #endregion

    #region 加密相关

    /// <summary>
    /// MD5加密
    /// </summary>
    /// <param name="strPwd"></param>
    /// <returns></returns>
    static public string EncryptMD5(string strPwd)
    {
        byte[] data = System.Text.Encoding.Default.GetBytes(strPwd);
        return EncryptMD5(data);
    }

    static public string EncryptMD5(byte[] bytes)
    {
        if (bytes == null || bytes.Length <= 0) return null;
        MD5 md5 = new MD5CryptoServiceProvider();
        byte[] data = bytes;
        byte[] md5data = md5.ComputeHash(data);
        md5.Clear();
        string str = "";
        for (int i = 0; i < md5data.Length - 1; i++)
        {
            str += md5data[i].ToString("x").PadLeft(2, '0');
        }
        return str;
    }

    static public string EncryptMD5ByPath(string path)
    {
        if (File.Exists(path))
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            using (var stream = new FileStream(path, FileMode.Open))
            {
                byte[] md5data = md5.ComputeHash(stream);
                md5.Clear();
                string str = "";
                for (int i = 0; i < md5data.Length - 1; i++)
                {
                    str += md5data[i].ToString("x").PadLeft(2, '0');
                }
                stream.Flush();
                stream.Close();
                return str;
            }
        }
        return null;
    }

    static public string EncryptMD5ByPath(string path, ref long len)
    {
        len = 0;
        if (File.Exists(path))
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            using (var stream = new FileStream(path, FileMode.Open))
            {
                len = stream.Length;
                byte[] md5data = md5.ComputeHash(stream);
                md5.Clear();
                string str = "";
                for (int i = 0; i < md5data.Length - 1; i++)
                {
                    str += md5data[i].ToString("x").PadLeft(2, '0');
                }
                stream.Flush();
                stream.Close();
                return str;
            }
        }
        return null;
    }

    static public string HashCodeToMd5(this object obj, string key = null)
    {
        if (obj != null)
        {
            return EncryptMD5(obj.GetHashCode().ToString());
        }
        return null;
    }

    static public object DefaultValue(this object obj, bool field = false, string fieldName = null)
    {
        object value = "";
        if (obj != null)
        {
            DefaultValueAttribute[] vs = null;
            if (!field) vs = obj.GetType().GetCustomAttributes(typeof(DefaultValueAttribute), false) as DefaultValueAttribute[];
            else
            {
                System.Reflection.FieldInfo fi = obj.GetType().GetField(!string.IsNullOrEmpty(fieldName) ? fieldName : obj.ToString());
                if (fi != null) vs = fi.GetCustomAttributes(typeof(DefaultValueAttribute), false) as DefaultValueAttribute[];
            }
            if (vs != null && vs.Length > 0)
            {
                value = vs[0].Value;
            }
        }
        return value;
    }

    /// <summary>
    /// 获取一个随机字符串
    /// </summary>
    /// <param name="maxlength">字符串长度</param>
    /// <returns></returns>
    static public string GetRandomString(int maxlength = 0)
    {
        string str = null;
        str = EncryptMD5(System.DateTime.Now.ToFileTime().ToString());
        if (maxlength > 0)
        {
            int l = (int)Math.Ceiling((double)maxlength / str.Length);
            for (int i = 0; i < l; i++)
            {
                str += EncryptMD5(System.DateTime.Now.ToShortDateString());
            }
            str = str.Substring(0, maxlength);
        }
        return str;
    }

    #endregion

    #endregion

}