﻿using System.Collections.Generic;

namespace AI.FSM
{
    using System;

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public sealed class FSEmumAttribute : Attribute
    {
        public Type group { get; set; }

        public int state { get; set; }

        public FSEmumAttribute()
        {

        }
    }

    public class FSMState : Emitter
    {
        #region Member

        private System.Action _exitCall;
        private bool _isFirst = true;

        protected int exitState { get; set; }
        protected virtual bool allowUpdate { get; set; }
        protected virtual bool refreshResetRuntime { get; set; }

        public int key { get; protected set; }
        public uint KID { get; private set; }
        public FSMMachine fsm { get; protected set; }
        public bool isRuning { get; protected set; }
        public bool isInited { get; private set; }
        public float runTime { get; private set; }

        protected bool hasDoEnter { get; private set; }
        protected string strValue { get; set; }

        public bool isEntered { get; private set; }
        public bool enbale { get; set; }
        public bool forbidInterrupt { get; set; } = false;
        public bool allowTransition { get; protected set; } = false;

        /// <summary>
        /// 允许自身切换到自身【eg. move=》move 】
        /// </summary>
        public virtual bool allowSelfSwitch { get { return true; } }

        #endregion

        #region 构造
        public FSMState()
        {
            GetFSEnum(this);
            _isFirst = true;
        }

        public FSMState(int name)
        {
            key = name;
            _isFirst = true;
        }
        #endregion

        #region Check

        /// <summary>
        /// 可否切换
        /// </summary>
        /// <param name="fsm"></param>
        /// <returns></returns>
        public virtual bool CheckCanSwitch(FSMMachine fsm)
        {
            return true;
        }

        /// <summary>
        /// 可否打断
        /// </summary>
        /// <param name="state"></param>
        /// <returns></returns>
        public virtual bool CheckCanInterrupt(int state)
        {
            return !forbidInterrupt;
        }

        /// <summary>
        /// 检查互斥
        /// </summary>
        /// <param name="state"></param>
        /// <returns></returns>
        public virtual bool CheckMutex(int state)
        {
            return true;
        }

        public virtual bool CheckStiffState(int state)
        {
            return (state > 1) && (state & (int)AI.Object.PlayerStateEnum.__Stiff) == state;
            //return MatchTools.IsInStiffState(state);
        }

        /// <summary>
        /// 检测状态完成
        /// </summary>
        /// <returns></returns>
        public virtual bool CheckCompleted()
        {
            return fsm != null && fsm.GetMark(key);
        }

        protected bool CheckExit()
        {
            if (_exitCall != null)
            {
                _exitCall();
                _exitCall = null;
                OnExit();
                return false;
            }
            return true;
        }

        protected virtual bool CheckExcuteOnEnter()
        {
            return true;
        }

        #endregion

        #region Excute

        /// <summary>
        /// 进入状态前的预处理
        /// </summary>
        public void PreEnter()
        {
            OnPreEnter();
        }

        /// <summary>
        /// 进入
        /// </summary>
        /// <param name="fsm"></param>
        public void Enter(FSMMachine fsm)
        {
            hasDoEnter = false;
            isEntered = false;
            if (!isRuning)
            {
                this.fsm = fsm;
                Marked(false);
                isRuning = true;
                runTime = 0;
                if (!isInited) { isInited = true; Init(); }
                if (_isFirst)
                {
                    _isFirst = false;
                    OnFirstEnter();
                }
                _exitCall = null;
                exitState = 0;
                if (CheckExcuteOnEnter())
                {
                    hasDoEnter = true;
                    isEntered = true;
                    OnEnter();
                    OnRefresh();
                }
            }
            else
            {
                Refresh();
            }
        }

        /// <summary>
        /// 刷新
        /// </summary>
        public void Refresh()
        {
            _exitCall = null;
            hasDoEnter = false;
            exitState = 0;
            Marked(false);
            if (refreshResetRuntime) runTime = 0;
            if (CheckExcuteOnEnter())
            {
                isEntered = true;
                OnRefresh();
            }
        }

        /// <summary>
        /// 帧更新
        /// </summary>
        /// <returns></returns>
        public int FSMUpdate(float time)
        {
            if (!isInited) { isInited = true; Init(); }
            else
            {
                runTime += time;
                var s = allowUpdate ? OnUpdate(time) : exitState;
                exitState = s == 0 ? exitState : s;
                if (CheckExit()) return s;
            }
            return 0;
        }

        /// <summary>
        /// 离开 如果返回false 则不会立即退出，需要等待自身决定什么时候退出，让后调用end回调
        /// </summary>
        /// <param name="end"></param>
        /// <returns></returns>
        public bool Exit(Action end = null)
        {
            isRuning = !OnExit();
            exitState = 0;
            if (isRuning) _exitCall = end;
            return !isRuning;
        }

        public void AfterExit()
        {
            isEntered = false;
            forbidInterrupt = false;
            OnAfterExit();
        }

        public virtual void Marked()
        {
            Marked(true);
        }

        public virtual int GetTransition(int next)
        {
            return next;
        }

        protected virtual object Argument()
        {

            return null;

        }

        protected virtual void Marked(bool state)
        {
            fsm?.Marked(key, state);
        }

        protected virtual void ChangeState(int state)
        {
            Marked();
            exitState = state;
        }

        #endregion

        #region On Excute

        public virtual void OnPreExcute(FSMMachine machine)
        {
            this.fsm = machine;
        }

        public virtual void OnPreUpdate(float time)
        {

        }

        protected virtual void OnFirstEnter() { }

        protected virtual void OnPreEnter() { }

        protected virtual void OnEnter() { }

        protected virtual void OnRefresh() { }

        protected virtual int OnUpdate(float time) => exitState;

        protected virtual bool OnExit() => true;

        protected virtual void OnAfterExit() { }

        #endregion

        #region Other

        public void SetKey(int key)
        {
            this.key = key;
            KID = this.key.ToID();
        }

        public virtual void Init() { }

        public virtual void UnInit()
        {
            if (isInited)
            {
                fsm = null;
                isInited = false;
                _exitCall = null;
                _isFirst = true;
                key = 0;
            }
        }

        public bool IsEnd()
        {
            return exitState != 0;
        }

        public override string ToString()
        {
            return string.IsNullOrEmpty(strValue) ? base.ToString() : String.Format("{0}[{1}]", base.ToString(), strValue);
        }

        #endregion

        #region static

        private static Dictionary<Type, int> _stateKeyDict = new Dictionary<Type, int>();

        private static void GetFSEnum(FSMState state)
        {
            if (state.key != 0) return;
            var type = state.GetType();
            var stateKey = 0;
            if (_stateKeyDict.TryGetValue(type, out stateKey))
            {
                state.key = stateKey;
                return;
            }

            var os = Attribute.GetCustomAttributes(state.GetType(), typeof(FSEmumAttribute)) as FSEmumAttribute[];
            if (os != null && os.Length == 1)
            {
                state.key = os[0].state;
                _stateKeyDict[type] = os[0].state;
            }
            else
            {
                _stateKeyDict[type] = 0;
            }
        }

        #endregion static
    }

    [FSM.FSEmum(group = typeof(void), state = -1)]
    public partial class DefaultState : FSMState
    {
        protected override void OnEnter()
        {
            Loger.Warn("<color=red>[{0}] </color>enter default state -> {1} ;  warring!!! ", fsm, key);
        }
    }
}
