﻿#if (__DEV__) || __IO__

using System.Collections.Generic;
using System.IO;
using System.Text;

namespace AI
{
    public class LogFile
    {
        static public LogType IOMask = LogType.__MAX__;
        static public string fileName;
        static public bool start = false;
        static public List<string> msgs = new List<string>();
        static public List<string> msgs2 = new List<string>();

        static TextWriter _logFile;
        static StringBuilder logStr;


        [UnityEngine.RuntimeInitializeOnLoadMethod()]
        static public void Excute()
        {
            ILog.logCountCB = () =>
            {
                return string.Format("{0:d4}", Match.G_FRAME);
                //return string.Format("{0:d4}|{1:d4}", Match.G_FRAME, Match.G_FIX_FRAME);
            };
            fileName = string.Format("Log/Log-{0}.txt", System.DateTime.Now.ToString(@"yy-MM-dd HH-mm-ss"));
            CommonUtil.CreateDir("Log");
            logStr = new StringBuilder();
            ILog.logCallBack += UnityLoger_logCallBack;

        }

        private static void UnityLoger_logCallBack(LogType arg1, string arg2)
        {
            if ((arg1 & IOMask) == arg1)
            {
                logStr?.AppendLine(arg2);
                msgs.Add(arg2);
                if (!start && Loop.isRuning)
                {
                    start = true;
                    _logFile = _logFile ?? new StreamWriter(fileName);
                    System.Threading.ThreadPool.QueueUserWorkItem((a) =>
                    {
                        while (Loop.isRuning)
                        {
                            System.Threading.Thread.Sleep(2000);
                            msgs2 = System.Threading.Interlocked.Exchange<List<string>>(ref msgs, msgs2);
                            try
                            {
                                foreach (var v in msgs2) _logFile.WriteLine(v);
                                _logFile.Flush();
                                msgs2.Clear();
                            }
                            catch (System.Exception e)
                            {
                                UnityEngine.Debug.LogException(e);
                            }
                        }
                        _logFile.Flush();
                        _logFile.Close();
                        _logFile.Dispose();
                        _logFile = null;
                        start = false;
                    });
                }
            }
        }
    }
}
#endif

