
namespace AI.FSM
{
    using System;
    using AI.Object;
    using AI.FSM.Auto;
    using System.Collections.Generic;
    using System.Linq;


    public class FSMMachine : FSMState
    {
        public static bool ShowLog = true;


        #region Member
        private readonly Dictionary<int, bool> _marks = new Dictionary<int, bool>();
        private readonly Dictionary<int, FSMState> _states = new Dictionary<int, FSMState>();
        public Action _switch;

        public int _cacheNextState;

        private FSMState _preNextState;

        public int firstState { get; private set; }
        public int lastState { get; protected set; }
        public int nextState { get; protected set; }
        public int transState { get; protected set; }
        public bool isStarted { get; protected set; }
        public virtual FSMState curState { get; protected set; }
        public virtual bool keepCurrentState { get { return false; } }
        public IDataSet datas { get; private set; }


        protected override bool allowUpdate => true;

        #endregion

        public FSMMachine()
        {
            _switch = new Action(_Switch);
            Singleton<FSMSystem>.Inst.AddItem(this);

        }

        #region State

        public FSMMachine SetFirst(int state)
        {
            firstState = state;
            return this;
        }

        public FSMMachine AddState(int key, FSMState state)
        {
            if (state != null && key > 0)
            {
                if (!_states.ContainsKey(key))
                {
                    state.SetKey(key);
                    _states.Add(key, state);
                }
            }
            return this;
        }

        public FSMMachine AddState<T>(int key) where T : FSMState, new()
        {
            return AddState(key, new T());
        }

        public FSMMachine RemoveState(FSMState state)
        {
            if (state != null && _states.ContainsKey(state.key))
                _states.Remove(state.key);
            return this;
        }

        public FSMMachine SetDatas(IDataSet data)
        {
            BindUpValue(false);
            datas = data;
            if (datas != null)
            {
                data.Set(MachineConst.C_STATE_MARKER_ID, (k) => { return GetMark(curState.key); }, null);
                if (curState != null) datas.Set(MachineConst.C_STATE_KEY_ID, curState.key);
                BindUpValue(true);
            }
            return this;
        }

        public FSMState RemoveState(int key)
        {
            if (_states.ContainsKey(key))
            {
                var s = _states[key];
                _states.Remove(key);
                return s;
            }
            return null;
        }

        public virtual FSMState GetState(int state, bool add = false)
        {
            if (state != 0)
            {
                if (_states.ContainsKey(state))
                {
                    return _states[state];
                }
            }
            return null;
        }

        public void Marked(int key, bool state)
        {
            _marks[key] = state;
            datas?.Set((uint)key, state);
        }

        /// <summary>
        /// 当前状态结束标记 true:结束 false:还在状态中
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool GetMark(int key)
        {
            bool s = false;
            _marks.TryGetValue(key, out s);
            return s;
        }

        public void BindUpValue(bool state = true, IDataSet data = null)
        {
            if (datas != null)
            {
                if (state)
                {
                    data = data ?? fsm?.datas;
                    if (data != null)
                    {
                        if (data != datas) datas.Set(MachineConst.C_UPVALUE_ID, data);
                        return;
                    }
                }
                datas.Del(MachineConst.C_UPVALUE_ID);
            }
        }

        public virtual int GetNextID(int id)
        {
            return 0;
        }



        #endregion

        #region Switch

        public virtual int GetDefaultNextState()
        {
            return firstState;
        }

        /// <summary>
        /// 状态切换
        /// </summary>
        /// <param name="state"></param>
        public virtual void Switch(int state)
        {
            var isMutex = true;
            if (state == 0)
            {
                Loger.Error("切换状态为空");
                return;
            }
            //检测是否允许切换状态
            if (CheckIsAllow(state, ref isMutex))
            {
                var s = GetState(state);
                if (s != null)
                {
                    if (s.CheckCanSwitch(this))
                    {

                        //#if __LOG__
                        //                        if (s is AI.MState) Loger.Warn("=========================<color=yellow>切换比赛状态为：{0}=>{1}</color>=====================", curState == null ? (MatchStateEnum)9999 : (MatchStateEnum)curState?.key, (MatchStateEnum)s?.key);
                        //#endif
                        if (_cacheNextState != 0 && state != _cacheNextState) GetState(_cacheNextState).Exit();
                        if (curState == s)
                        {
                            curState.SetKey(state);
                            curState.Refresh();
                            _cacheNextState = 0;
                        }
                        else
                        {
                            s.PreEnter();
                            _cacheNextState = state;
                            if (curState != null && isMutex && !curState.Exit(_switch)) return;
                            if (curState == null || (curState != s && curState.key != state))
                            {
                                _cacheNextState = state;
                                _Switch();
                            }
                        }
                    }
                }
                else if (!keepCurrentState || curState == null)
                {
                    Loger.Error("不存在绑定枚举为{0}的状态", state);
                    var n = GetDefaultNextState();
                    if (state != n) Switch(n);
                }
            }
            else
            {
                Loger.Error("{0} switch {1}->{2} fail", this, curState.key, state);
            }
        }

        public virtual FSMState PreExcute(int state)
        {
            _preNextState = null;
            if (state == 0) return null;
            if (curState != null && curState.key == state) return null;
            if (_preNextState != null && _preNextState.key == state) return null;
            var s = GetState(state);
            if (s != null)
            {
                _preNextState = s;
                _preNextState.OnPreExcute(this);
            }
            return _preNextState;
        }

        public void _Switch(int next, bool isTrans = false)
        {
            if (next != 0)
            {
                var nk = next;

                if (nk == nextState)
                {
                    if (!isTrans && transState != 0) return;
                    isTrans = true;
                }
                _preNextState = null;
                var s = GetState(nk);

                if (curState != null && curState.CheckMutex(nk))
                {
                    if (!isTrans && s.allowTransition)
                    {
                        var t = curState.GetTransition(nk);
                        if (t != nk && t != 0)
                        {
                            var ts = GetState(t, true);
                            if (ts != null && ts != curState)
                            {
                                nextState = nk;
                                _Switch(t, true);
                                nextState = nk;
                                transState = t;
                                return;
                            }
                        }
                    }
                    curState.AfterExit();
                    lastState = curState.key;
                    Marked(lastState, false);
                }
                if (s.isRuning) s.Exit();
                if (ShowLog) Loger.Warn(string.Format("FSM[{0}->{3}:{4}]->Enter:[{1}:{2}]", this, nk, s, curState?.key, curState));
                curState = s;
                datas?.Set(MachineConst.C_STATE_KEY_ID, nk);
                curState.SetKey(nk);
                curState.Enter(this);
                datas?.Set(MachineConst.C_STATE_ENTER_ID, s.isEntered);
                OnSwitch();
                nextState = 0;
                transState = 0;
            }
            else
            {
                Loger.Error("Next State Is Null");
            }
        }

        public void _Switch()
        {
            _cacheNextState = _cacheNextState == 0 ? firstState : _cacheNextState;
            _Switch(_cacheNextState);
            _cacheNextState = 0;
        }

        private void DoUpdateState(float time)
        {
            if (curState != null)
            {
                var next = curState.FSMUpdate(time);
                var flag = curState.CheckCompleted();
                if (next == 0 && nextState != 0 && flag)
                {
                    next = nextState;
                    transState = 0;
                }
                if (next != 0)
                    Switch(next);
                else if (flag)
                    OnStateCompleted(curState);
            }
        }

        private void DoUpdatePreState(float time)
        {
            _preNextState?.OnPreUpdate(time);
            _preNextState?.FSMUpdate(time);
        }
        #endregion

        #region Check

        public bool CheckCanSwitch(int state)
        {
            var s = GetState(state);
            return s != null && s.CheckCanSwitch(this);
        }

        /// <summary>
        /// 检测是否允许切换状态
        /// </summary>
        /// <param name="state"></param>
        /// <param name="isMutex"></param>
        /// <returns></returns>
        /// Last Modified by 杨煜涵
        /// Last Modified time 2022-09-26
        /// Last Requirement 添加状态切换失败打印
        /// Last Designed by 肖剑
        protected virtual bool CheckIsAllow(int state, ref bool isMutex)
        {
            //此状态是否结束
            bool getMark = false;
            //硬直状态
            bool checkStiffState = false;
            //可否打断
            bool checkCanInterrupt = false;
            //是否互斥
            bool CheckMutex = false;

            if (state != 0)
            {
                if (curState == null) return true;
                isMutex = true;
                var s = state == curState.key;

                getMark = GetMark(curState.key);
                checkStiffState = curState.CheckStiffState(state);
                checkCanInterrupt = curState.CheckCanInterrupt(state);
                CheckMutex = !(isMutex = curState.CheckMutex(state));


                if (!s && getMark || checkStiffState || checkCanInterrupt || CheckMutex) return true;
                if (s && curState.allowSelfSwitch) return true;
            }

            Loger.Error($"[无法切换状态] 当前状态:{(PlayerStateEnum)curState.key} 目标状态:{(PlayerStateEnum)state} getMark:{getMark} checkStiffState:{checkStiffState} checkCanInterrupt:{checkCanInterrupt} CheckMutex:{CheckMutex} allowSelfSwitch:{curState.allowSelfSwitch}");
            return false;
        }

        protected virtual bool CheckSwitchDefault()
        {
            return true;
        }

        #endregion

        #region Override

        protected sealed override void OnEnter()
        {
            base.OnEnter();
            isStarted = true;
            BindUpValue();
            if (CheckSwitchDefault())
                Switch(GetDefaultNextState());
            OnStart();
        }

        protected override int OnUpdate(float time)
        {
            DoUpdateState(time);
            DoUpdatePreState(time);
            return exitState;
        }

        protected override bool OnExit()
        {
            curState?.Exit();
            _preNextState?.Exit();
            curState = null;
            _preNextState = null;
            lastState = 0;
            _cacheNextState = 0;
            isStarted = false;
            BindUpValue(false);
            return true;
        }

        public override void UnInit()
        {
            if (isInited)
            {
                if (_states.Count > 0)
                {
                    foreach (var v in _states) v.Value.UnInit();
                }
                _states.Clear();
                firstState = 0;
                _cacheNextState = 0;
                curState = null;
                lastState = 0;
                isStarted = false;
                datas?.Clear();
                _preNextState = null;
            }
            base.UnInit();
        }

        protected virtual void OnStart() { }

        protected virtual void OnSwitch() { }

        protected virtual void OnStateCompleted(FSMState state)
        {

        }

        public override string ToString()
        {
            if (fsm != null) return String.Format("{0}.{1}", fsm, base.ToString());
            return base.ToString();
        }

        #endregion

        #region Static



        static private Dictionary<Type, Dictionary<int, Type>> _allStates;

        static public FSMState CreateState<T>(int key, bool useDefault = true)
        {
            return CreateState(typeof(T), key, true);
        }

        static public FSMState CreateState(Type type, int key, bool useDefault = true)
        {
            if (type != null && key >= 0)
            {
                Dictionary<int, Type> dic = null;
                if (_allStates.TryGetValue(type, out dic) && dic != null)
                {
                    if (dic.ContainsKey(key) && dic[key] != null)
                        return Activator.CreateInstance(dic[key]) as FSMState;
                    else if (dic.ContainsKey(-1) && dic[-1] != null)
                        return Activator.CreateInstance(dic[-1]) as FSMState;
                }
                return type == typeof(void) || !useDefault ? null : CreateState(typeof(void), 0);

            }
            return null;
        }

        #endregion

        private class FSMSystem : System<FSMMachine>
        {
            protected override bool Filter(FSMMachine component)
            {
                return base.Filter(component) && component.fsm == null && component.allowUpdate;
            }

            protected override void Update(float time, FSMMachine component)
            {
                component.OnUpdate(time);
            }

            protected override void Awake()
            {
                if (_allStates == null)
                {
                    _allStates = new Dictionary<Type, Dictionary<int, Type>>();
                    Type[] ts;

                    DateTime sart = DateTime.Now;

                    if (Zeus.Launch.HotLaunch.Instance.DEBUG_MODEL)
                    {
                        System.Reflection.Assembly cSharp = AppDomain.CurrentDomain.GetAssemblies().First(assembly => assembly.GetName().Name == "Assembly-CSharp");
                        ts = cSharp.GetTypes();


                        var end = DateTime.Now;
                        double totalMs = (end - sart).TotalMilliseconds;
                        UnityEngine.Debug.LogError(string.Format("{0} {1} /ms", "[AI:Machine] Assembly GetTypes -> Used time:", totalMs));
                    }
                    else
                    {
                        ts = Zeus.Launch.HotLaunch.Instance.GameAsset.GetTypes();
                    }

                    var bt = typeof(FSM.FSMState);
                    foreach (var v in ts)
                    {
                        if (bt.IsAssignableFrom(v))
                        {
                            var ls = Attribute.GetCustomAttributes(v, typeof(FSM.FSEmumAttribute), false) as FSEmumAttribute[];
                            if (ls != null && ls.Length > 0)
                            {
                                foreach (var a in ls)
                                {
                                    if (a.group != null)
                                    {
                                        Dictionary<int, Type> dic = null;
                                        if (!_allStates.TryGetValue(a.group, out dic))
                                            _allStates[a.group] = dic = new Dictionary<int, Type>();
                                        dic[a.state] = v;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }

    public class FSMMachine<T> : FSMMachine where T : FSMState
    {
        private bool _isInitState = false;

        protected override void OnFirstEnter()
        {
            base.OnFirstEnter();
            //Log();
            InitState();
        }

        protected virtual void InitState()
        {
            if (_isInitState) return;
            _isInitState = true;
            var s = CreateState<T>(key) ?? CreateState<T>(0);
            if (s == null)
            {
                Loger.Error(string.Format("[{0}]没有绑定初始状态,FSEmum(type=typeof({1}))标记", this.GetType().Name, typeof(T).Name));
            }
            else
            {
                s.SetKey(key == 0 ? 1 : key);
                SetFirst(s.key);
                AddState(s.key, s);
            }
        }

        public override FSMState PreExcute(int state)
        {
            if (GetState(state, true) != null)
                return base.PreExcute(state);
            return null;
        }

        public override void Switch(int state)
        {
            if (state != 0)
            {
                if (GetState(state, true) != null)


                    base.Switch(state);
            }
        }


        public override void UnInit()
        {
            _isInitState = false;
            base.UnInit();
        }

        public override FSMState GetState(int state, bool add = false)
        {
            if (state == 0) return null;
            var s = base.GetState(state, add);
            if (s == null && add)
            {
                s = CreateState<T>(state, false);
                if (s == null)
                {
                    var replace = GetNextReplacementState(state);
                    s = CreateState<T>(replace != 0 ? replace : state);
                }
                if (s != null)
                {
                    s.SetKey(state);
                    AddState(state, s);
                }
                else Loger.Error(string.Format("不存在绑定Key为【{0}】的【{1}】状态", state, typeof(T)));
            }
            return s;
        }


        protected virtual int GetNextReplacementState(int state)
        {
            return 0;
        }


    }


}
